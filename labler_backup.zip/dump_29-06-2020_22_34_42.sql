--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE labler;




--
-- Drop roles
--

DROP ROLE postgres;


--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'md5e77cbcaf48c4749fc6ec4d1dee9ff1fe';






--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE template1 OWNER TO postgres;

\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\connect template1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

--
-- Database "labler" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: labler; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE labler WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE labler OWNER TO postgres;

\connect labler

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: image_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.image_groups (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    userid integer NOT NULL,
    categoryid integer NOT NULL
);


ALTER TABLE public.image_groups OWNER TO postgres;

--
-- Name: image_groups_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.image_groups_categoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_groups_categoryid_seq OWNER TO postgres;

--
-- Name: image_groups_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.image_groups_categoryid_seq OWNED BY public.image_groups.categoryid;


--
-- Name: image_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.image_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_groups_id_seq OWNER TO postgres;

--
-- Name: image_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.image_groups_id_seq OWNED BY public.image_groups.id;


--
-- Name: image_groups_userid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.image_groups_userid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.image_groups_userid_seq OWNER TO postgres;

--
-- Name: image_groups_userid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.image_groups_userid_seq OWNED BY public.image_groups.userid;


--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id integer NOT NULL,
    name text NOT NULL,
    filename character varying(255) NOT NULL,
    groupid integer NOT NULL,
    width integer,
    height integer
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_groupid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_groupid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.images_groupid_seq OWNER TO postgres;

--
-- Name: images_groupid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_groupid_seq OWNED BY public.images.groupid;


--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: labelings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.labelings (
    id integer NOT NULL,
    startx integer DEFAULT 0 NOT NULL,
    starty integer DEFAULT 0 NOT NULL,
    endx integer DEFAULT 0 NOT NULL,
    endy integer DEFAULT 0 NOT NULL,
    labelid integer NOT NULL,
    imageid integer NOT NULL
);


ALTER TABLE public.labelings OWNER TO postgres;

--
-- Name: labelings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.labelings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labelings_id_seq OWNER TO postgres;

--
-- Name: labelings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.labelings_id_seq OWNED BY public.labelings.id;


--
-- Name: labelings_imageid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.labelings_imageid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labelings_imageid_seq OWNER TO postgres;

--
-- Name: labelings_imageid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.labelings_imageid_seq OWNED BY public.labelings.imageid;


--
-- Name: labelings_labelid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.labelings_labelid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labelings_labelid_seq OWNER TO postgres;

--
-- Name: labelings_labelid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.labelings_labelid_seq OWNED BY public.labelings.labelid;


--
-- Name: labels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.labels (
    id integer NOT NULL,
    name text NOT NULL,
    color text NOT NULL,
    groupid integer NOT NULL
);


ALTER TABLE public.labels OWNER TO postgres;

--
-- Name: labels_groupid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.labels_groupid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labels_groupid_seq OWNER TO postgres;

--
-- Name: labels_groupid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.labels_groupid_seq OWNED BY public.labels.groupid;


--
-- Name: labels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.labels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labels_id_seq OWNER TO postgres;

--
-- Name: labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.labels_id_seq OWNED BY public.labels.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password character varying(255) NOT NULL,
    email character varying(50)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: image_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups ALTER COLUMN id SET DEFAULT nextval('public.image_groups_id_seq'::regclass);


--
-- Name: image_groups userid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups ALTER COLUMN userid SET DEFAULT nextval('public.image_groups_userid_seq'::regclass);


--
-- Name: image_groups categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups ALTER COLUMN categoryid SET DEFAULT nextval('public.image_groups_categoryid_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: images groupid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN groupid SET DEFAULT nextval('public.images_groupid_seq'::regclass);


--
-- Name: labelings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings ALTER COLUMN id SET DEFAULT nextval('public.labelings_id_seq'::regclass);


--
-- Name: labelings labelid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings ALTER COLUMN labelid SET DEFAULT nextval('public.labelings_labelid_seq'::regclass);


--
-- Name: labelings imageid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings ALTER COLUMN imageid SET DEFAULT nextval('public.labelings_imageid_seq'::regclass);


--
-- Name: labels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labels ALTER COLUMN id SET DEFAULT nextval('public.labels_id_seq'::regclass);


--
-- Name: labels groupid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labels ALTER COLUMN groupid SET DEFAULT nextval('public.labels_groupid_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name) FROM stdin;
1	YOLOv3
\.


--
-- Data for Name: image_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.image_groups (id, name, userid, categoryid) FROM stdin;
12	Shoes	2	1
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, name, filename, groupid, width, height) FROM stdin;
22	frame-1107.jpg	files/12/1590495332630_frame-1107.jpg	12	1920	1080
23	frame-1097.jpg	files/12/1590495332712_frame-1097.jpg	12	1920	1080
24	frame-1106.jpg	files/12/1590495332647_frame-1106.jpg	12	1920	1080
26	frame-1104.jpg	files/12/1590495332666_frame-1104.jpg	12	1920	1080
25	frame-1105.jpg	files/12/1590495332657_frame-1105.jpg	12	1920	1080
27	frame-1102.jpg	files/12/1590495332681_frame-1102.jpg	12	1920	1080
29	frame-1101.jpg	files/12/1590495332687_frame-1101.jpg	12	1920	1080
28	frame-1103.jpg	files/12/1590495332675_frame-1103.jpg	12	1920	1080
30	frame-1100.jpg	files/12/1590495332693_frame-1100.jpg	12	1920	1080
31	frame-1098.jpg	files/12/1590495332706_frame-1098.jpg	12	1920	1080
32	frame-1099.jpg	files/12/1590495332700_frame-1099.jpg	12	1920	1080
33	frame-1096.jpg	files/12/1590495332722_frame-1096.jpg	12	1920	1080
35	frame-1093.jpg	files/12/1590495332740_frame-1093.jpg	12	1920	1080
34	frame-1095.jpg	files/12/1590495332728_frame-1095.jpg	12	1920	1080
36	frame-1094.jpg	files/12/1590495332735_frame-1094.jpg	12	1920	1080
37	frame-1091.jpg	files/12/1590495332753_frame-1091.jpg	12	1920	1080
38	frame-1092.jpg	files/12/1590495332747_frame-1092.jpg	12	1920	1080
40	frame-1089.jpg	files/12/1590495332768_frame-1089.jpg	12	1920	1080
39	frame-1090.jpg	files/12/1590495332767_frame-1090.jpg	12	1920	1080
41	frame-1087.jpg	files/12/1590495332779_frame-1087.jpg	12	1920	1080
42	frame-1088.jpg	files/12/1590495332773_frame-1088.jpg	12	1920	1080
45	frame-1084.jpg	files/12/1590495332802_frame-1084.jpg	12	1920	1080
44	frame-1085.jpg	files/12/1590495332795_frame-1085.jpg	12	1920	1080
43	frame-1086.jpg	files/12/1590495332788_frame-1086.jpg	12	1920	1080
46	frame-1083.jpg	files/12/1590495332807_frame-1083.jpg	12	1920	1080
47	frame-1082.jpg	files/12/1590495332814_frame-1082.jpg	12	1920	1080
48	frame-1081.jpg	files/12/1590495332820_frame-1081.jpg	12	1920	1080
49	frame-1079.jpg	files/12/1590495332833_frame-1079.jpg	12	1920	1080
50	frame-1080.jpg	files/12/1590495332826_frame-1080.jpg	12	1920	1080
51	frame-1078.jpg	files/12/1590495332839_frame-1078.jpg	12	1920	1080
52	frame-1077.jpg	files/12/1590495332846_frame-1077.jpg	12	1920	1080
53	frame-1076.jpg	files/12/1590495332852_frame-1076.jpg	12	1920	1080
54	frame-1075.jpg	files/12/1590495332858_frame-1075.jpg	12	1920	1080
55	frame-1074.jpg	files/12/1590495332865_frame-1074.jpg	12	1920	1080
56	frame-1073.jpg	files/12/1590495332871_frame-1073.jpg	12	1920	1080
57	frame-1072.jpg	files/12/1590495332877_frame-1072.jpg	12	1920	1080
58	frame-1071.jpg	files/12/1590495332883_frame-1071.jpg	12	1920	1080
59	frame-1070.jpg	files/12/1590495332890_frame-1070.jpg	12	1920	1080
60	frame-1069.jpg	files/12/1590495332896_frame-1069.jpg	12	1920	1080
61	frame-1067.jpg	files/12/1590495332913_frame-1067.jpg	12	1920	1080
62	frame-1068.jpg	files/12/1590495332907_frame-1068.jpg	12	1920	1080
63	frame-1066.jpg	files/12/1590495332925_frame-1066.jpg	12	1920	1080
64	frame-1065.jpg	files/12/1590495332926_frame-1065.jpg	12	1920	1080
65	frame-1064.jpg	files/12/1590495332931_frame-1064.jpg	12	1920	1080
66	frame-1063.jpg	files/12/1590495332938_frame-1063.jpg	12	1920	1080
67	frame-1062.jpg	files/12/1590495332944_frame-1062.jpg	12	1920	1080
68	frame-1061.jpg	files/12/1590495332950_frame-1061.jpg	12	1920	1080
69	frame-1060.jpg	files/12/1590495332961_frame-1060.jpg	12	1920	1080
70	frame-1059.jpg	files/12/1590495332963_frame-1059.jpg	12	1920	1080
71	frame-1058.jpg	files/12/1590495332969_frame-1058.jpg	12	1920	1080
72	frame-1057.jpg	files/12/1590495332976_frame-1057.jpg	12	1920	1080
73	frame-1055.jpg	files/12/1590495332993_frame-1055.jpg	12	1920	1080
74	frame-1056.jpg	files/12/1590495332986_frame-1056.jpg	12	1920	1080
75	frame-1054.jpg	files/12/1590495332998_frame-1054.jpg	12	1920	1080
76	frame-1053.jpg	files/12/1590495333005_frame-1053.jpg	12	1920	1080
77	frame-1050.jpg	files/12/1590495333023_frame-1050.jpg	12	1920	1080
78	frame-1052.jpg	files/12/1590495333011_frame-1052.jpg	12	1920	1080
79	frame-1049.jpg	files/12/1590495333029_frame-1049.jpg	12	1920	1080
80	frame-1051.jpg	files/12/1590495333017_frame-1051.jpg	12	1920	1080
81	frame-1048.jpg	files/12/1590495333036_frame-1048.jpg	12	1920	1080
82	frame-1047.jpg	files/12/1590495333045_frame-1047.jpg	12	1920	1080
83	frame-1046.jpg	files/12/1590495333051_frame-1046.jpg	12	1920	1080
99	frame-1030.jpg	files/12/1590495333155_frame-1030.jpg	12	1920	1080
110	frame-1019.jpg	files/12/1590495333228_frame-1019.jpg	12	1920	1080
120	frame-1010.jpg	files/12/1590495333281_frame-1010.jpg	12	1920	1080
134	frame-995.jpg	files/12/1590495333377_frame-995.jpg	12	1920	1080
144	frame-985.jpg	files/12/1590495333445_frame-985.jpg	12	1920	1080
154	frame-975.jpg	files/12/1590495333571_frame-975.jpg	12	1920	1080
170	frame-958.jpg	files/12/1590495333617_frame-958.jpg	12	1920	1080
180	frame-949.jpg	files/12/1590495333675_frame-949.jpg	12	1920	1080
190	frame-938.jpg	files/12/1590495333748_frame-938.jpg	12	1920	1080
200	frame-928.jpg	files/12/1590495333812_frame-928.jpg	12	1920	1080
211	frame-920.jpg	files/12/1590495333861_frame-920.jpg	12	1920	1080
220	frame-909.jpg	files/12/1590495333933_frame-909.jpg	12	1920	1080
236	frame-890.jpg	files/12/1590495334056_frame-890.jpg	12	1920	1080
247	frame-881.jpg	files/12/1590495334114_frame-881.jpg	12	1920	1080
257	frame-872.jpg	files/12/1590495334173_frame-872.jpg	12	1920	1080
266	frame-862.jpg	files/12/1590495334237_frame-862.jpg	12	1920	1080
281	frame-848.jpg	files/12/1590495334327_frame-848.jpg	12	1920	1080
291	frame-838.jpg	files/12/1590495334391_frame-838.jpg	12	1920	1080
302	frame-827.jpg	files/12/1590495334464_frame-827.jpg	12	1920	1080
313	frame-816.jpg	files/12/1590495334537_frame-816.jpg	12	1920	1080
326	frame-803.jpg	files/12/1590495334614_frame-803.jpg	12	1920	1080
336	frame-792.jpg	files/12/1590495334684_frame-792.jpg	12	1920	1080
348	frame-780.jpg	files/12/1590495334761_frame-780.jpg	12	1920	1080
360	frame-769.jpg	files/12/1590495334832_frame-769.jpg	12	1920	1080
370	frame-760.jpg	files/12/1590495334890_frame-760.jpg	12	1920	1080
383	frame-746.jpg	files/12/1590495334981_frame-746.jpg	12	1920	1080
394	frame-735.jpg	files/12/1590495335049_frame-735.jpg	12	1920	1080
404	frame-725.jpg	files/12/1590495335114_frame-725.jpg	12	1920	1080
417	frame-712.jpg	files/12/1590495335200_frame-712.jpg	12	1920	1080
429	frame-700.jpg	files/12/1590495335278_frame-700.jpg	12	1920	1080
439	frame-690.jpg	files/12/1590495335338_frame-690.jpg	12	1920	1080
450	frame-679.jpg	files/12/1590495335409_frame-679.jpg	12	1920	1080
463	frame-666.jpg	files/12/1590495335492_frame-666.jpg	12	1920	1080
473	frame-656.jpg	files/12/1590495335556_frame-656.jpg	12	1920	1080
484	frame-645.jpg	files/12/1590495335630_frame-645.jpg	12	1920	1080
502	frame-627.jpg	files/12/1590495335740_frame-627.jpg	12	1920	1080
515	frame-614.jpg	files/12/1590495335823_frame-614.jpg	12	1920	1080
525	frame-604.jpg	files/12/1590495335887_frame-604.jpg	12	1920	1080
538	frame-592.jpg	files/12/1590495335965_frame-592.jpg	12	1920	1080
551	frame-580.jpg	files/12/1590495336037_frame-580.jpg	12	1920	1080
561	frame-567.jpg	files/12/1590495336120_frame-567.jpg	12	1920	1080
574	frame-552.jpg	files/12/1590495336219_frame-552.jpg	12	1920	1080
587	frame-555.jpg	files/12/1590495336200_frame-555.jpg	12	1920	1080
597	frame-532.jpg	files/12/1590495336344_frame-532.jpg	12	1920	1080
610	frame-519.jpg	files/12/1590495336426_frame-519.jpg	12	1920	1080
622	frame-507.jpg	files/12/1590495336500_frame-507.jpg	12	1920	1080
635	frame-494.jpg	files/12/1590495336585_frame-494.jpg	12	1920	1080
645	frame-484.jpg	files/12/1590495336650_frame-484.jpg	12	1920	1080
654	frame-475.jpg	files/12/1590495336747_frame-475.jpg	12	1920	1080
664	frame-465.jpg	files/12/1590495336766_frame-465.jpg	12	1920	1080
673	frame-456.jpg	files/12/1590495336822_frame-456.jpg	12	1920	1080
687	frame-442.jpg	files/12/1590495336914_frame-442.jpg	12	1920	1080
700	frame-429.jpg	files/12/1590495336996_frame-429.jpg	12	1920	1080
710	frame-419.jpg	files/12/1590495337059_frame-419.jpg	12	1920	1080
724	frame-405.jpg	files/12/1590495337148_frame-405.jpg	12	1920	1080
737	frame-392.jpg	files/12/1590495337231_frame-392.jpg	12	1920	1080
747	frame-382.jpg	files/12/1590495337295_frame-382.jpg	12	1920	1080
756	frame-373.jpg	files/12/1590495337353_frame-373.jpg	12	1920	1080
766	frame-363.jpg	files/12/1590495337418_frame-363.jpg	12	1920	1080
775	frame-354.jpg	files/12/1590495337473_frame-354.jpg	12	1920	1080
785	frame-344.jpg	files/12/1590495337537_frame-344.jpg	12	1920	1080
799	frame-330.jpg	files/12/1590495337626_frame-330.jpg	12	1920	1080
813	frame-316.jpg	files/12/1590495337718_frame-316.jpg	12	1920	1080
827	frame-302.jpg	files/12/1590495337804_frame-302.jpg	12	1920	1080
837	frame-292.jpg	files/12/1590495337868_frame-292.jpg	12	1920	1080
851	frame-278.jpg	files/12/1590495337954_frame-278.jpg	12	1920	1080
865	frame-264.jpg	files/12/1590495338046_frame-264.jpg	12	1920	1080
878	frame-251.jpg	files/12/1590495338129_frame-251.jpg	12	1920	1080
888	frame-241.jpg	files/12/1590495338193_frame-241.jpg	12	1920	1080
899	frame-230.jpg	files/12/1590495338261_frame-230.jpg	12	1920	1080
911	frame-218.jpg	files/12/1590495338337_frame-218.jpg	12	1920	1080
921	frame-208.jpg	files/12/1590495338401_frame-208.jpg	12	1920	1080
932	frame-197.jpg	files/12/1590495338472_frame-197.jpg	12	1920	1080
949	frame-180.jpg	files/12/1590495338582_frame-180.jpg	12	1920	1080
960	frame-169.jpg	files/12/1590495338651_frame-169.jpg	12	1920	1080
975	frame-154.jpg	files/12/1590495338744_frame-154.jpg	12	1920	1080
985	frame-144.jpg	files/12/1590495338813_frame-144.jpg	12	1920	1080
995	frame-134.jpg	files/12/1590495338880_frame-134.jpg	12	1920	1080
1009	frame-120.jpg	files/12/1590495338966_frame-120.jpg	12	1920	1080
1019	frame-110.jpg	files/12/1590495339027_frame-110.jpg	12	1920	1080
84	frame-1045.jpg	files/12/1590495333058_frame-1045.jpg	12	1920	1080
98	frame-1031.jpg	files/12/1590495333146_frame-1031.jpg	12	1920	1080
109	frame-1020.jpg	files/12/1590495333217_frame-1020.jpg	12	1920	1080
119	frame-1009.jpg	files/12/1590495333287_frame-1009.jpg	12	1920	1080
135	frame-994.jpg	files/12/1590495333386_frame-994.jpg	12	1920	1080
145	frame-984.jpg	files/12/1590495333451_frame-984.jpg	12	1920	1080
155	frame-974.jpg	files/12/1590495333584_frame-974.jpg	12	1920	1080
171	frame-957.jpg	files/12/1590495333624_frame-957.jpg	12	1920	1080
181	frame-948.jpg	files/12/1590495333681_frame-948.jpg	12	1920	1080
192	frame-936.jpg	files/12/1590495333760_frame-936.jpg	12	1920	1080
203	frame-926.jpg	files/12/1590495333824_frame-926.jpg	12	1920	1080
218	frame-912.jpg	files/12/1590495333913_frame-912.jpg	12	1920	1080
229	frame-901.jpg	files/12/1590495333993_frame-901.jpg	12	1920	1080
239	frame-891.jpg	files/12/1590495334049_frame-891.jpg	12	1920	1080
255	frame-874.jpg	files/12/1590495334161_frame-874.jpg	12	1920	1080
267	frame-863.jpg	files/12/1590495334228_frame-863.jpg	12	1920	1080
282	frame-847.jpg	files/12/1590495334335_frame-847.jpg	12	1920	1080
292	frame-837.jpg	files/12/1590495334397_frame-837.jpg	12	1920	1080
303	frame-826.jpg	files/12/1590495334470_frame-826.jpg	12	1920	1080
314	frame-815.jpg	files/12/1590495334541_frame-815.jpg	12	1920	1080
327	frame-802.jpg	files/12/1590495334620_frame-802.jpg	12	1920	1080
337	frame-794.jpg	files/12/1590495334673_frame-794.jpg	12	1920	1080
349	frame-782.jpg	files/12/1590495334748_frame-782.jpg	12	1920	1080
361	frame-768.jpg	files/12/1590495334842_frame-768.jpg	12	1920	1080
371	frame-758.jpg	files/12/1590495334907_frame-758.jpg	12	1920	1080
382	frame-747.jpg	files/12/1590495334975_frame-747.jpg	12	1920	1080
395	frame-734.jpg	files/12/1590495335056_frame-734.jpg	12	1920	1080
405	frame-724.jpg	files/12/1590495335121_frame-724.jpg	12	1920	1080
416	frame-713.jpg	files/12/1590495335195_frame-713.jpg	12	1920	1080
428	frame-701.jpg	files/12/1590495335271_frame-701.jpg	12	1920	1080
438	frame-691.jpg	files/12/1590495335332_frame-691.jpg	12	1920	1080
451	frame-677.jpg	files/12/1590495335421_frame-677.jpg	12	1920	1080
462	frame-667.jpg	files/12/1590495335486_frame-667.jpg	12	1920	1080
472	frame-657.jpg	files/12/1590495335551_frame-657.jpg	12	1920	1080
485	frame-644.jpg	files/12/1590495335633_frame-644.jpg	12	1920	1080
501	frame-628.jpg	files/12/1590495335737_frame-628.jpg	12	1920	1080
514	frame-615.jpg	files/12/1590495335816_frame-615.jpg	12	1920	1080
524	frame-605.jpg	files/12/1590495335881_frame-605.jpg	12	1920	1080
537	frame-591.jpg	files/12/1590495335969_frame-591.jpg	12	1920	1080
550	frame-578.jpg	files/12/1590495336056_frame-578.jpg	12	1920	1080
560	frame-569.jpg	files/12/1590495336107_frame-569.jpg	12	1920	1080
573	frame-553.jpg	files/12/1590495336211_frame-553.jpg	12	1920	1080
586	frame-556.jpg	files/12/1590495336191_frame-556.jpg	12	1920	1080
596	frame-533.jpg	files/12/1590495336338_frame-533.jpg	12	1920	1080
609	frame-520.jpg	files/12/1590495336420_frame-520.jpg	12	1920	1080
623	frame-506.jpg	files/12/1590495336511_frame-506.jpg	12	1920	1080
636	frame-493.jpg	files/12/1590495336592_frame-493.jpg	12	1920	1080
650	frame-479.jpg	files/12/1590495336744_frame-479.jpg	12	1920	1080
660	frame-469.jpg	files/12/1590495336752_frame-469.jpg	12	1920	1080
674	frame-455.jpg	files/12/1590495336833_frame-455.jpg	12	1920	1080
688	frame-441.jpg	files/12/1590495336919_frame-441.jpg	12	1920	1080
701	frame-428.jpg	files/12/1590495337003_frame-428.jpg	12	1920	1080
711	frame-418.jpg	files/12/1590495337066_frame-418.jpg	12	1920	1080
725	frame-404.jpg	files/12/1590495337154_frame-404.jpg	12	1920	1080
738	frame-391.jpg	files/12/1590495337237_frame-391.jpg	12	1920	1080
752	frame-377.jpg	files/12/1590495337329_frame-377.jpg	12	1920	1080
762	frame-367.jpg	files/12/1590495337393_frame-367.jpg	12	1920	1080
776	frame-353.jpg	files/12/1590495337479_frame-353.jpg	12	1920	1080
789	frame-340.jpg	files/12/1590495337561_frame-340.jpg	12	1920	1080
798	frame-331.jpg	files/12/1590495337620_frame-331.jpg	12	1920	1080
807	frame-322.jpg	files/12/1590495337678_frame-322.jpg	12	1920	1080
817	frame-312.jpg	files/12/1590495337743_frame-312.jpg	12	1920	1080
826	frame-303.jpg	files/12/1590495337798_frame-303.jpg	12	1920	1080
836	frame-293.jpg	files/12/1590495337859_frame-293.jpg	12	1920	1080
845	frame-284.jpg	files/12/1590495337917_frame-284.jpg	12	1920	1080
855	frame-274.jpg	files/12/1590495337982_frame-274.jpg	12	1920	1080
863	frame-266.jpg	files/12/1590495338033_frame-266.jpg	12	1920	1080
873	frame-256.jpg	files/12/1590495338098_frame-256.jpg	12	1920	1080
882	frame-247.jpg	files/12/1590495338156_frame-247.jpg	12	1920	1080
895	frame-234.jpg	files/12/1590495338236_frame-234.jpg	12	1920	1080
905	frame-224.jpg	files/12/1590495338301_frame-224.jpg	12	1920	1080
916	frame-213.jpg	files/12/1590495338372_frame-213.jpg	12	1920	1080
929	frame-200.jpg	files/12/1590495338459_frame-200.jpg	12	1920	1080
939	frame-190.jpg	files/12/1590495338518_frame-190.jpg	12	1920	1080
948	frame-181.jpg	files/12/1590495338574_frame-181.jpg	12	1920	1080
958	frame-171.jpg	files/12/1590495338637_frame-171.jpg	12	1920	1080
967	frame-162.jpg	files/12/1590495338696_frame-162.jpg	12	1920	1080
977	frame-152.jpg	files/12/1590495338757_frame-152.jpg	12	1920	1080
991	frame-138.jpg	files/12/1590495338849_frame-138.jpg	12	1920	1080
1001	frame-128.jpg	files/12/1590495338915_frame-128.jpg	12	1920	1080
1013	frame-116.jpg	files/12/1590495338990_frame-116.jpg	12	1920	1080
85	frame-1044.jpg	files/12/1590495333064_frame-1044.jpg	12	1920	1080
93	frame-1036.jpg	files/12/1590495333116_frame-1036.jpg	12	1920	1080
103	frame-1026.jpg	files/12/1590495333180_frame-1026.jpg	12	1920	1080
111	frame-1018.jpg	files/12/1590495333229_frame-1018.jpg	12	1920	1080
121	frame-1008.jpg	files/12/1590495333293_frame-1008.jpg	12	1920	1080
128	frame-1000.jpg	files/12/1590495333346_frame-1000.jpg	12	1920	1080
138	frame-992.jpg	files/12/1590495333398_frame-992.jpg	12	1920	1080
146	frame-981.jpg	files/12/1590495333540_frame-981.jpg	12	1920	1080
156	frame-973.jpg	files/12/1590495333585_frame-973.jpg	12	1920	1080
164	frame-967.jpg	files/12/1590495333592_frame-967.jpg	12	1920	1080
174	frame-954.jpg	files/12/1590495333642_frame-954.jpg	12	1920	1080
189	frame-939.jpg	files/12/1590495333742_frame-939.jpg	12	1920	1080
199	frame-929.jpg	files/12/1590495333806_frame-929.jpg	12	1920	1080
209	frame-919.jpg	files/12/1590495333868_frame-919.jpg	12	1920	1080
217	frame-911.jpg	files/12/1590495333920_frame-911.jpg	12	1920	1080
227	frame-902.jpg	files/12/1590495333992_frame-902.jpg	12	1920	1080
235	frame-894.jpg	files/12/1590495334028_frame-894.jpg	12	1920	1080
245	frame-883.jpg	files/12/1590495334101_frame-883.jpg	12	1920	1080
254	frame-875.jpg	files/12/1590495334155_frame-875.jpg	12	1920	1080
263	frame-867.jpg	files/12/1590495334204_frame-867.jpg	12	1920	1080
273	frame-854.jpg	files/12/1590495334288_frame-854.jpg	12	1920	1080
284	frame-846.jpg	files/12/1590495334343_frame-846.jpg	12	1920	1080
294	frame-835.jpg	files/12/1590495334412_frame-835.jpg	12	1920	1080
304	frame-825.jpg	files/12/1590495334476_frame-825.jpg	12	1920	1080
310	frame-819.jpg	files/12/1590495334516_frame-819.jpg	12	1920	1080
320	frame-809.jpg	files/12/1590495334577_frame-809.jpg	12	1920	1080
328	frame-801.jpg	files/12/1590495334629_frame-801.jpg	12	1920	1080
338	frame-791.jpg	files/12/1590495334691_frame-791.jpg	12	1920	1080
345	frame-789.jpg	files/12/1590495334703_frame-789.jpg	12	1920	1080
355	frame-774.jpg	files/12/1590495334802_frame-774.jpg	12	1920	1080
362	frame-767.jpg	files/12/1590495334848_frame-767.jpg	12	1920	1080
372	frame-757.jpg	files/12/1590495334913_frame-757.jpg	12	1920	1080
379	frame-749.jpg	files/12/1590495334962_frame-749.jpg	12	1920	1080
389	frame-739.jpg	files/12/1590495335025_frame-739.jpg	12	1920	1080
396	frame-732.jpg	files/12/1590495335071_frame-732.jpg	12	1920	1080
406	frame-723.jpg	files/12/1590495335130_frame-723.jpg	12	1920	1080
413	frame-716.jpg	files/12/1590495335176_frame-716.jpg	12	1920	1080
423	frame-706.jpg	files/12/1590495335237_frame-706.jpg	12	1920	1080
430	frame-699.jpg	files/12/1590495335283_frame-699.jpg	12	1920	1080
440	frame-689.jpg	files/12/1590495335344_frame-689.jpg	12	1920	1080
447	frame-682.jpg	files/12/1590495335391_frame-682.jpg	12	1920	1080
457	frame-672.jpg	files/12/1590495335453_frame-672.jpg	12	1920	1080
464	frame-665.jpg	files/12/1590495335498_frame-665.jpg	12	1920	1080
474	frame-655.jpg	files/12/1590495335562_frame-655.jpg	12	1920	1080
481	frame-648.jpg	files/12/1590495335609_frame-648.jpg	12	1920	1080
491	frame-639.jpg	files/12/1590495335663_frame-639.jpg	12	1920	1080
497	frame-632.jpg	files/12/1590495335709_frame-632.jpg	12	1920	1080
507	frame-623.jpg	files/12/1590495335764_frame-623.jpg	12	1920	1080
516	frame-613.jpg	files/12/1590495335828_frame-613.jpg	12	1920	1080
526	frame-603.jpg	files/12/1590495335893_frame-603.jpg	12	1920	1080
533	frame-596.jpg	files/12/1590495335945_frame-596.jpg	12	1920	1080
543	frame-586.jpg	files/12/1590495336001_frame-586.jpg	12	1920	1080
552	frame-576.jpg	files/12/1590495336065_frame-576.jpg	12	1920	1080
562	frame-568.jpg	files/12/1590495336114_frame-568.jpg	12	1920	1080
569	frame-559.jpg	files/12/1590495336172_frame-559.jpg	12	1920	1080
579	frame-547.jpg	files/12/1590495336252_frame-547.jpg	12	1920	1080
588	frame-541.jpg	files/12/1590495336292_frame-541.jpg	12	1920	1080
598	frame-531.jpg	files/12/1590495336349_frame-531.jpg	12	1920	1080
605	frame-524.jpg	files/12/1590495336393_frame-524.jpg	12	1920	1080
615	frame-514.jpg	files/12/1590495336457_frame-514.jpg	12	1920	1080
624	frame-505.jpg	files/12/1590495336515_frame-505.jpg	12	1920	1080
632	frame-497.jpg	files/12/1590495336567_frame-497.jpg	12	1920	1080
642	frame-487.jpg	files/12/1590495336628_frame-487.jpg	12	1920	1080
651	frame-478.jpg	files/12/1590495336745_frame-478.jpg	12	1920	1080
661	frame-468.jpg	files/12/1590495336753_frame-468.jpg	12	1920	1080
670	frame-459.jpg	files/12/1590495336803_frame-459.jpg	12	1920	1080
679	frame-450.jpg	files/12/1590495336861_frame-450.jpg	12	1920	1080
689	frame-440.jpg	files/12/1590495336926_frame-440.jpg	12	1920	1080
697	frame-432.jpg	files/12/1590495336978_frame-432.jpg	12	1920	1080
707	frame-422.jpg	files/12/1590495337041_frame-422.jpg	12	1920	1080
716	frame-413.jpg	files/12/1590495337096_frame-413.jpg	12	1920	1080
726	frame-403.jpg	files/12/1590495337160_frame-403.jpg	12	1920	1080
734	frame-395.jpg	files/12/1590495337209_frame-395.jpg	12	1920	1080
744	frame-385.jpg	files/12/1590495337277_frame-385.jpg	12	1920	1080
753	frame-376.jpg	files/12/1590495337335_frame-376.jpg	12	1920	1080
763	frame-366.jpg	files/12/1590495337401_frame-366.jpg	12	1920	1080
772	frame-357.jpg	files/12/1590495337454_frame-357.jpg	12	1920	1080
782	frame-347.jpg	files/12/1590495337515_frame-347.jpg	12	1920	1080
790	frame-339.jpg	files/12/1590495337567_frame-339.jpg	12	1920	1080
800	frame-329.jpg	files/12/1590495337632_frame-329.jpg	12	1920	1080
809	frame-320.jpg	files/12/1590495337690_frame-320.jpg	12	1920	1080
86	frame-1043.jpg	files/12/1590495333069_frame-1043.jpg	12	1920	1080
94	frame-1033.jpg	files/12/1590495333134_frame-1033.jpg	12	1920	1080
104	frame-1023.jpg	files/12/1590495333199_frame-1023.jpg	12	1920	1080
112	frame-1016.jpg	files/12/1590495333241_frame-1016.jpg	12	1920	1080
122	frame-1004.jpg	files/12/1590495333319_frame-1004.jpg	12	1920	1080
129	frame-1001.jpg	files/12/1590495333340_frame-1001.jpg	12	1920	1080
139	frame-991.jpg	files/12/1590495333404_frame-991.jpg	12	1920	1080
147	frame-983.jpg	files/12/1590495333535_frame-983.jpg	12	1920	1080
157	frame-972.jpg	files/12/1590495333586_frame-972.jpg	12	1920	1080
165	frame-963.jpg	files/12/1590495333596_frame-963.jpg	12	1920	1080
175	frame-960.jpg	files/12/1590495333605_frame-960.jpg	12	1920	1080
184	frame-945.jpg	files/12/1590495333700_frame-945.jpg	12	1920	1080
194	frame-940.jpg	files/12/1590495333735_frame-940.jpg	12	1920	1080
204	frame-923.jpg	files/12/1590495333843_frame-923.jpg	12	1920	1080
213	frame-915.jpg	files/12/1590495333895_frame-915.jpg	12	1920	1080
222	frame-905.jpg	files/12/1590495333960_frame-905.jpg	12	1920	1080
230	frame-899.jpg	files/12/1590495334001_frame-899.jpg	12	1920	1080
240	frame-889.jpg	files/12/1590495334069_frame-889.jpg	12	1920	1080
249	frame-882.jpg	files/12/1590495334109_frame-882.jpg	12	1920	1080
258	frame-871.jpg	files/12/1590495334179_frame-871.jpg	12	1920	1080
268	frame-861.jpg	files/12/1590495334246_frame-861.jpg	12	1920	1080
276	frame-856.jpg	files/12/1590495334276_frame-856.jpg	12	1920	1080
286	frame-843.jpg	files/12/1590495334359_frame-843.jpg	12	1920	1080
297	frame-832.jpg	files/12/1590495334430_frame-832.jpg	12	1920	1080
307	frame-822.jpg	files/12/1590495334495_frame-822.jpg	12	1920	1080
317	frame-812.jpg	files/12/1590495334559_frame-812.jpg	12	1920	1080
324	frame-805.jpg	files/12/1590495334602_frame-805.jpg	12	1920	1080
334	frame-795.jpg	files/12/1590495334667_frame-795.jpg	12	1920	1080
342	frame-785.jpg	files/12/1590495334731_frame-785.jpg	12	1920	1080
352	frame-777.jpg	files/12/1590495334780_frame-777.jpg	12	1920	1080
364	frame-765.jpg	files/12/1590495334861_frame-765.jpg	12	1920	1080
376	frame-753.jpg	files/12/1590495334941_frame-753.jpg	12	1920	1080
386	frame-743.jpg	files/12/1590495334999_frame-743.jpg	12	1920	1080
398	frame-730.jpg	files/12/1590495335083_frame-730.jpg	12	1920	1080
410	frame-719.jpg	files/12/1590495335154_frame-719.jpg	12	1920	1080
420	frame-709.jpg	files/12/1590495335221_frame-709.jpg	12	1920	1080
432	frame-697.jpg	files/12/1590495335298_frame-697.jpg	12	1920	1080
444	frame-685.jpg	files/12/1590495335369_frame-685.jpg	12	1920	1080
454	frame-675.jpg	files/12/1590495335433_frame-675.jpg	12	1920	1080
466	frame-663.jpg	files/12/1590495335513_frame-663.jpg	12	1920	1080
478	frame-651.jpg	files/12/1590495335590_frame-651.jpg	12	1920	1080
488	frame-641.jpg	files/12/1590495335651_frame-641.jpg	12	1920	1080
495	frame-635.jpg	files/12/1590495335688_frame-635.jpg	12	1920	1080
505	frame-625.jpg	files/12/1590495335752_frame-625.jpg	12	1920	1080
512	frame-617.jpg	files/12/1590495335804_frame-617.jpg	12	1920	1080
522	frame-607.jpg	files/12/1590495335869_frame-607.jpg	12	1920	1080
531	frame-598.jpg	files/12/1590495335937_frame-598.jpg	12	1920	1080
541	frame-589.jpg	files/12/1590495335982_frame-589.jpg	12	1920	1080
548	frame-581.jpg	files/12/1590495336031_frame-581.jpg	12	1920	1080
558	frame-572.jpg	files/12/1590495336089_frame-572.jpg	12	1920	1080
567	frame-562.jpg	files/12/1590495336153_frame-562.jpg	12	1920	1080
577	frame-549.jpg	files/12/1590495336236_frame-549.jpg	12	1920	1080
584	frame-542.jpg	files/12/1590495336282_frame-542.jpg	12	1920	1080
594	frame-535.jpg	files/12/1590495336325_frame-535.jpg	12	1920	1080
603	frame-526.jpg	files/12/1590495336385_frame-526.jpg	12	1920	1080
613	frame-516.jpg	files/12/1590495336447_frame-516.jpg	12	1920	1080
620	frame-509.jpg	files/12/1590495336487_frame-509.jpg	12	1920	1080
630	frame-499.jpg	files/12/1590495336552_frame-499.jpg	12	1920	1080
639	frame-490.jpg	files/12/1590495336610_frame-490.jpg	12	1920	1080
648	frame-481.jpg	files/12/1590495336741_frame-481.jpg	12	1920	1080
658	frame-471.jpg	files/12/1590495336751_frame-471.jpg	12	1920	1080
667	frame-462.jpg	files/12/1590495336785_frame-462.jpg	12	1920	1080
677	frame-452.jpg	files/12/1590495336850_frame-452.jpg	12	1920	1080
685	frame-444.jpg	files/12/1590495336898_frame-444.jpg	12	1920	1080
695	frame-434.jpg	files/12/1590495336963_frame-434.jpg	12	1920	1080
704	frame-425.jpg	files/12/1590495337021_frame-425.jpg	12	1920	1080
714	frame-415.jpg	files/12/1590495337085_frame-415.jpg	12	1920	1080
722	frame-407.jpg	files/12/1590495337135_frame-407.jpg	12	1920	1080
732	frame-397.jpg	files/12/1590495337197_frame-397.jpg	12	1920	1080
741	frame-388.jpg	files/12/1590495337255_frame-388.jpg	12	1920	1080
750	frame-379.jpg	files/12/1590495337316_frame-379.jpg	12	1920	1080
760	frame-369.jpg	files/12/1590495337385_frame-369.jpg	12	1920	1080
769	frame-360.jpg	files/12/1590495337445_frame-360.jpg	12	1920	1080
779	frame-350.jpg	files/12/1590495337498_frame-350.jpg	12	1920	1080
788	frame-341.jpg	files/12/1590495337555_frame-341.jpg	12	1920	1080
797	frame-332.jpg	files/12/1590495337614_frame-332.jpg	12	1920	1080
806	frame-323.jpg	files/12/1590495337672_frame-323.jpg	12	1920	1080
816	frame-313.jpg	files/12/1590495337740_frame-313.jpg	12	1920	1080
825	frame-304.jpg	files/12/1590495337791_frame-304.jpg	12	1920	1080
835	frame-294.jpg	files/12/1590495337853_frame-294.jpg	12	1920	1080
844	frame-285.jpg	files/12/1590495337911_frame-285.jpg	12	1920	1080
87	frame-1042.jpg	files/12/1590495333078_frame-1042.jpg	12	1920	1080
95	frame-1032.jpg	files/12/1590495333140_frame-1032.jpg	12	1920	1080
105	frame-1025.jpg	files/12/1590495333192_frame-1025.jpg	12	1920	1080
113	frame-1015.jpg	files/12/1590495333247_frame-1015.jpg	12	1920	1080
123	frame-1007.jpg	files/12/1590495333300_frame-1007.jpg	12	1920	1080
130	frame-999.jpg	files/12/1590495333352_frame-999.jpg	12	1920	1080
140	frame-989.jpg	files/12/1590495333417_frame-989.jpg	12	1920	1080
148	frame-980.jpg	files/12/1590495333547_frame-980.jpg	12	1920	1080
158	frame-971.jpg	files/12/1590495333587_frame-971.jpg	12	1920	1080
166	frame-962.jpg	files/12/1590495333597_frame-962.jpg	12	1920	1080
176	frame-952.jpg	files/12/1590495333661_frame-952.jpg	12	1920	1080
185	frame-944.jpg	files/12/1590495333709_frame-944.jpg	12	1920	1080
195	frame-931.jpg	files/12/1590495333794_frame-931.jpg	12	1920	1080
205	frame-924.jpg	files/12/1590495333839_frame-924.jpg	12	1920	1080
223	frame-907.jpg	files/12/1590495333945_frame-907.jpg	12	1920	1080
231	frame-898.jpg	files/12/1590495334005_frame-898.jpg	12	1920	1080
241	frame-886.jpg	files/12/1590495334082_frame-886.jpg	12	1920	1080
250	frame-879.jpg	files/12/1590495334127_frame-879.jpg	12	1920	1080
259	frame-870.jpg	files/12/1590495334185_frame-870.jpg	12	1920	1080
269	frame-860.jpg	files/12/1590495334252_frame-860.jpg	12	1920	1080
277	frame-852.jpg	files/12/1590495334300_frame-852.jpg	12	1920	1080
287	frame-841.jpg	files/12/1590495334371_frame-841.jpg	12	1920	1080
298	frame-831.jpg	files/12/1590495334437_frame-831.jpg	12	1920	1080
308	frame-821.jpg	files/12/1590495334501_frame-821.jpg	12	1920	1080
318	frame-811.jpg	files/12/1590495334565_frame-811.jpg	12	1920	1080
330	frame-799.jpg	files/12/1590495334642_frame-799.jpg	12	1920	1080
343	frame-784.jpg	files/12/1590495334737_frame-784.jpg	12	1920	1080
353	frame-776.jpg	files/12/1590495334790_frame-776.jpg	12	1920	1080
365	frame-764.jpg	files/12/1590495334866_frame-764.jpg	12	1920	1080
377	frame-751.jpg	files/12/1590495334950_frame-751.jpg	12	1920	1080
387	frame-742.jpg	files/12/1590495335005_frame-742.jpg	12	1920	1080
399	frame-731.jpg	files/12/1590495335077_frame-731.jpg	12	1920	1080
411	frame-718.jpg	files/12/1590495335161_frame-718.jpg	12	1920	1080
421	frame-708.jpg	files/12/1590495335225_frame-708.jpg	12	1920	1080
433	frame-696.jpg	files/12/1590495335302_frame-696.jpg	12	1920	1080
446	frame-683.jpg	files/12/1590495335384_frame-683.jpg	12	1920	1080
456	frame-674.jpg	files/12/1590495335440_frame-674.jpg	12	1920	1080
468	frame-661.jpg	files/12/1590495335525_frame-661.jpg	12	1920	1080
479	frame-650.jpg	files/12/1590495335596_frame-650.jpg	12	1920	1080
489	frame-640.jpg	files/12/1590495335657_frame-640.jpg	12	1920	1080
499	frame-629.jpg	files/12/1590495335728_frame-629.jpg	12	1920	1080
509	frame-620.jpg	files/12/1590495335782_frame-620.jpg	12	1920	1080
518	frame-611.jpg	files/12/1590495335841_frame-611.jpg	12	1920	1080
528	frame-599.jpg	files/12/1590495335929_frame-599.jpg	12	1920	1080
535	frame-594.jpg	files/12/1590495335957_frame-594.jpg	12	1920	1080
545	frame-585.jpg	files/12/1590495336007_frame-585.jpg	12	1920	1080
554	frame-575.jpg	files/12/1590495336071_frame-575.jpg	12	1920	1080
564	frame-565.jpg	files/12/1590495336132_frame-565.jpg	12	1920	1080
571	frame-558.jpg	files/12/1590495336178_frame-558.jpg	12	1920	1080
581	frame-545.jpg	files/12/1590495336264_frame-545.jpg	12	1920	1080
590	frame-539.jpg	files/12/1590495336302_frame-539.jpg	12	1920	1080
600	frame-529.jpg	files/12/1590495336362_frame-529.jpg	12	1920	1080
607	frame-522.jpg	files/12/1590495336405_frame-522.jpg	12	1920	1080
617	frame-512.jpg	files/12/1590495336469_frame-512.jpg	12	1920	1080
626	frame-503.jpg	files/12/1590495336527_frame-503.jpg	12	1920	1080
634	frame-495.jpg	files/12/1590495336580_frame-495.jpg	12	1920	1080
644	frame-485.jpg	files/12/1590495336644_frame-485.jpg	12	1920	1080
653	frame-476.jpg	files/12/1590495336747_frame-476.jpg	12	1920	1080
663	frame-466.jpg	files/12/1590495336760_frame-466.jpg	12	1920	1080
672	frame-457.jpg	files/12/1590495336816_frame-457.jpg	12	1920	1080
681	frame-448.jpg	files/12/1590495336874_frame-448.jpg	12	1920	1080
691	frame-438.jpg	files/12/1590495336938_frame-438.jpg	12	1920	1080
699	frame-430.jpg	files/12/1590495336990_frame-430.jpg	12	1920	1080
709	frame-420.jpg	files/12/1590495337053_frame-420.jpg	12	1920	1080
718	frame-411.jpg	files/12/1590495337111_frame-411.jpg	12	1920	1080
728	frame-401.jpg	files/12/1590495337173_frame-401.jpg	12	1920	1080
736	frame-393.jpg	files/12/1590495337228_frame-393.jpg	12	1920	1080
746	frame-383.jpg	files/12/1590495337289_frame-383.jpg	12	1920	1080
755	frame-374.jpg	files/12/1590495337347_frame-374.jpg	12	1920	1080
765	frame-364.jpg	files/12/1590495337411_frame-364.jpg	12	1920	1080
774	frame-355.jpg	files/12/1590495337466_frame-355.jpg	12	1920	1080
784	frame-345.jpg	files/12/1590495337527_frame-345.jpg	12	1920	1080
792	frame-337.jpg	files/12/1590495337580_frame-337.jpg	12	1920	1080
802	frame-327.jpg	files/12/1590495337644_frame-327.jpg	12	1920	1080
811	frame-318.jpg	files/12/1590495337702_frame-318.jpg	12	1920	1080
821	frame-308.jpg	files/12/1590495337767_frame-308.jpg	12	1920	1080
830	frame-299.jpg	files/12/1590495337822_frame-299.jpg	12	1920	1080
840	frame-289.jpg	files/12/1590495337886_frame-289.jpg	12	1920	1080
849	frame-280.jpg	files/12/1590495337942_frame-280.jpg	12	1920	1080
858	frame-271.jpg	files/12/1590495338009_frame-271.jpg	12	1920	1080
868	frame-261.jpg	files/12/1590495338064_frame-261.jpg	12	1920	1080
88	frame-1041.jpg	files/12/1590495333092_frame-1041.jpg	12	1920	1080
96	frame-1034.jpg	files/12/1590495333128_frame-1034.jpg	12	1920	1080
106	frame-1024.jpg	files/12/1590495333193_frame-1024.jpg	12	1920	1080
114	frame-1017.jpg	files/12/1590495333235_frame-1017.jpg	12	1920	1080
124	frame-1003.jpg	files/12/1590495333325_frame-1003.jpg	12	1920	1080
131	frame-998.jpg	files/12/1590495333358_frame-998.jpg	12	1920	1080
141	frame-988.jpg	files/12/1590495333426_frame-988.jpg	12	1920	1080
149	frame-982.jpg	files/12/1590495333539_frame-982.jpg	12	1920	1080
159	frame-969.jpg	files/12/1590495333590_frame-969.jpg	12	1920	1080
167	frame-961.jpg	files/12/1590495333600_frame-961.jpg	12	1920	1080
177	frame-950.jpg	files/12/1590495333669_frame-950.jpg	12	1920	1080
186	frame-942.jpg	files/12/1590495333723_frame-942.jpg	12	1920	1080
196	frame-933.jpg	files/12/1590495333784_frame-933.jpg	12	1920	1080
206	frame-925.jpg	files/12/1590495333831_frame-925.jpg	12	1920	1080
214	frame-914.jpg	files/12/1590495333901_frame-914.jpg	12	1920	1080
224	frame-906.jpg	files/12/1590495333953_frame-906.jpg	12	1920	1080
232	frame-897.jpg	files/12/1590495334016_frame-897.jpg	12	1920	1080
242	frame-885.jpg	files/12/1590495334089_frame-885.jpg	12	1920	1080
251	frame-877.jpg	files/12/1590495334142_frame-877.jpg	12	1920	1080
260	frame-869.jpg	files/12/1590495334192_frame-869.jpg	12	1920	1080
270	frame-858.jpg	files/12/1590495334264_frame-858.jpg	12	1920	1080
278	frame-849.jpg	files/12/1590495334325_frame-849.jpg	12	1920	1080
288	frame-842.jpg	files/12/1590495334365_frame-842.jpg	12	1920	1080
300	frame-829.jpg	files/12/1590495334449_frame-829.jpg	12	1920	1080
311	frame-818.jpg	files/12/1590495334522_frame-818.jpg	12	1920	1080
321	frame-808.jpg	files/12/1590495334584_frame-808.jpg	12	1920	1080
329	frame-800.jpg	files/12/1590495334636_frame-800.jpg	12	1920	1080
339	frame-790.jpg	files/12/1590495334697_frame-790.jpg	12	1920	1080
346	frame-788.jpg	files/12/1590495334709_frame-788.jpg	12	1920	1080
356	frame-770.jpg	files/12/1590495334826_frame-770.jpg	12	1920	1080
363	frame-766.jpg	files/12/1590495334854_frame-766.jpg	12	1920	1080
373	frame-756.jpg	files/12/1590495334918_frame-756.jpg	12	1920	1080
380	frame-750.jpg	files/12/1590495334956_frame-750.jpg	12	1920	1080
390	frame-741.jpg	files/12/1590495335011_frame-741.jpg	12	1920	1080
397	frame-733.jpg	files/12/1590495335065_frame-733.jpg	12	1920	1080
407	frame-722.jpg	files/12/1590495335137_frame-722.jpg	12	1920	1080
414	frame-714.jpg	files/12/1590495335193_frame-714.jpg	12	1920	1080
424	frame-705.jpg	files/12/1590495335246_frame-705.jpg	12	1920	1080
431	frame-698.jpg	files/12/1590495335290_frame-698.jpg	12	1920	1080
441	frame-688.jpg	files/12/1590495335350_frame-688.jpg	12	1920	1080
448	frame-681.jpg	files/12/1590495335396_frame-681.jpg	12	1920	1080
458	frame-671.jpg	files/12/1590495335461_frame-671.jpg	12	1920	1080
465	frame-664.jpg	files/12/1590495335504_frame-664.jpg	12	1920	1080
475	frame-654.jpg	files/12/1590495335569_frame-654.jpg	12	1920	1080
482	frame-647.jpg	files/12/1590495335615_frame-647.jpg	12	1920	1080
492	frame-637.jpg	files/12/1590495335676_frame-637.jpg	12	1920	1080
498	frame-630.jpg	files/12/1590495335722_frame-630.jpg	12	1920	1080
508	frame-621.jpg	files/12/1590495335776_frame-621.jpg	12	1920	1080
517	frame-612.jpg	files/12/1590495335835_frame-612.jpg	12	1920	1080
527	frame-602.jpg	files/12/1590495335902_frame-602.jpg	12	1920	1080
534	frame-595.jpg	files/12/1590495335946_frame-595.jpg	12	1920	1080
544	frame-583.jpg	files/12/1590495336019_frame-583.jpg	12	1920	1080
553	frame-577.jpg	files/12/1590495336059_frame-577.jpg	12	1920	1080
563	frame-566.jpg	files/12/1590495336126_frame-566.jpg	12	1920	1080
570	frame-560.jpg	files/12/1590495336165_frame-560.jpg	12	1920	1080
580	frame-546.jpg	files/12/1590495336258_frame-546.jpg	12	1920	1080
589	frame-540.jpg	files/12/1590495336294_frame-540.jpg	12	1920	1080
599	frame-530.jpg	files/12/1590495336356_frame-530.jpg	12	1920	1080
606	frame-523.jpg	files/12/1590495336399_frame-523.jpg	12	1920	1080
616	frame-513.jpg	files/12/1590495336463_frame-513.jpg	12	1920	1080
625	frame-504.jpg	files/12/1590495336521_frame-504.jpg	12	1920	1080
633	frame-496.jpg	files/12/1590495336573_frame-496.jpg	12	1920	1080
643	frame-486.jpg	files/12/1590495336638_frame-486.jpg	12	1920	1080
652	frame-477.jpg	files/12/1590495336746_frame-477.jpg	12	1920	1080
662	frame-467.jpg	files/12/1590495336755_frame-467.jpg	12	1920	1080
671	frame-458.jpg	files/12/1590495336809_frame-458.jpg	12	1920	1080
680	frame-449.jpg	files/12/1590495336868_frame-449.jpg	12	1920	1080
690	frame-439.jpg	files/12/1590495336933_frame-439.jpg	12	1920	1080
698	frame-431.jpg	files/12/1590495336984_frame-431.jpg	12	1920	1080
708	frame-421.jpg	files/12/1590495337047_frame-421.jpg	12	1920	1080
717	frame-412.jpg	files/12/1590495337102_frame-412.jpg	12	1920	1080
727	frame-402.jpg	files/12/1590495337166_frame-402.jpg	12	1920	1080
735	frame-394.jpg	files/12/1590495337215_frame-394.jpg	12	1920	1080
745	frame-384.jpg	files/12/1590495337283_frame-384.jpg	12	1920	1080
754	frame-375.jpg	files/12/1590495337341_frame-375.jpg	12	1920	1080
764	frame-365.jpg	files/12/1590495337405_frame-365.jpg	12	1920	1080
773	frame-356.jpg	files/12/1590495337460_frame-356.jpg	12	1920	1080
783	frame-346.jpg	files/12/1590495337521_frame-346.jpg	12	1920	1080
791	frame-338.jpg	files/12/1590495337574_frame-338.jpg	12	1920	1080
801	frame-328.jpg	files/12/1590495337638_frame-328.jpg	12	1920	1080
810	frame-319.jpg	files/12/1590495337696_frame-319.jpg	12	1920	1080
89	frame-1040.jpg	files/12/1590495333093_frame-1040.jpg	12	1920	1080
97	frame-1035.jpg	files/12/1590495333122_frame-1035.jpg	12	1920	1080
107	frame-1022.jpg	files/12/1590495333205_frame-1022.jpg	12	1920	1080
115	frame-1014.jpg	files/12/1590495333254_frame-1014.jpg	12	1920	1080
125	frame-1006.jpg	files/12/1590495333306_frame-1006.jpg	12	1920	1080
132	frame-997.jpg	files/12/1590495333365_frame-997.jpg	12	1920	1080
142	frame-986.jpg	files/12/1590495333439_frame-986.jpg	12	1920	1080
150	frame-979.jpg	files/12/1590495333553_frame-979.jpg	12	1920	1080
160	frame-970.jpg	files/12/1590495333589_frame-970.jpg	12	1920	1080
168	frame-964.jpg	files/12/1590495333595_frame-964.jpg	12	1920	1080
178	frame-953.jpg	files/12/1590495333648_frame-953.jpg	12	1920	1080
187	frame-941.jpg	files/12/1590495333729_frame-941.jpg	12	1920	1080
197	frame-932.jpg	files/12/1590495333788_frame-932.jpg	12	1920	1080
207	frame-922.jpg	files/12/1590495333849_frame-922.jpg	12	1920	1080
215	frame-917.jpg	files/12/1590495333884_frame-917.jpg	12	1920	1080
225	frame-904.jpg	files/12/1590495333966_frame-904.jpg	12	1920	1080
233	frame-895.jpg	files/12/1590495334022_frame-895.jpg	12	1920	1080
243	frame-888.jpg	files/12/1590495334070_frame-888.jpg	12	1920	1080
252	frame-876.jpg	files/12/1590495334148_frame-876.jpg	12	1920	1080
261	frame-868.jpg	files/12/1590495334197_frame-868.jpg	12	1920	1080
271	frame-859.jpg	files/12/1590495334258_frame-859.jpg	12	1920	1080
279	frame-850.jpg	files/12/1590495334320_frame-850.jpg	12	1920	1080
289	frame-840.jpg	files/12/1590495334381_frame-840.jpg	12	1920	1080
299	frame-830.jpg	files/12/1590495334444_frame-830.jpg	12	1920	1080
309	frame-820.jpg	files/12/1590495334510_frame-820.jpg	12	1920	1080
319	frame-810.jpg	files/12/1590495334572_frame-810.jpg	12	1920	1080
331	frame-797.jpg	files/12/1590495334654_frame-797.jpg	12	1920	1080
344	frame-783.jpg	files/12/1590495334743_frame-783.jpg	12	1920	1080
354	frame-775.jpg	files/12/1590495334796_frame-775.jpg	12	1920	1080
366	frame-763.jpg	files/12/1590495334872_frame-763.jpg	12	1920	1080
378	frame-752.jpg	files/12/1590495334943_frame-752.jpg	12	1920	1080
388	frame-740.jpg	files/12/1590495335021_frame-740.jpg	12	1920	1080
400	frame-729.jpg	files/12/1590495335090_frame-729.jpg	12	1920	1080
412	frame-717.jpg	files/12/1590495335167_frame-717.jpg	12	1920	1080
422	frame-707.jpg	files/12/1590495335232_frame-707.jpg	12	1920	1080
434	frame-695.jpg	files/12/1590495335308_frame-695.jpg	12	1920	1080
445	frame-684.jpg	files/12/1590495335378_frame-684.jpg	12	1920	1080
455	frame-673.jpg	files/12/1590495335445_frame-673.jpg	12	1920	1080
467	frame-662.jpg	files/12/1590495335519_frame-662.jpg	12	1920	1080
480	frame-649.jpg	files/12/1590495335602_frame-649.jpg	12	1920	1080
490	frame-638.jpg	files/12/1590495335669_frame-638.jpg	12	1920	1080
500	frame-631.jpg	files/12/1590495335715_frame-631.jpg	12	1920	1080
513	frame-616.jpg	files/12/1590495335810_frame-616.jpg	12	1920	1080
523	frame-606.jpg	files/12/1590495335875_frame-606.jpg	12	1920	1080
536	frame-593.jpg	files/12/1590495335958_frame-593.jpg	12	1920	1080
549	frame-579.jpg	files/12/1590495336043_frame-579.jpg	12	1920	1080
559	frame-570.jpg	files/12/1590495336102_frame-570.jpg	12	1920	1080
572	frame-557.jpg	files/12/1590495336185_frame-557.jpg	12	1920	1080
585	frame-554.jpg	files/12/1590495336206_frame-554.jpg	12	1920	1080
595	frame-534.jpg	files/12/1590495336332_frame-534.jpg	12	1920	1080
608	frame-521.jpg	files/12/1590495336414_frame-521.jpg	12	1920	1080
621	frame-508.jpg	files/12/1590495336494_frame-508.jpg	12	1920	1080
631	frame-498.jpg	files/12/1590495336558_frame-498.jpg	12	1920	1080
640	frame-489.jpg	files/12/1590495336616_frame-489.jpg	12	1920	1080
649	frame-480.jpg	files/12/1590495336742_frame-480.jpg	12	1920	1080
659	frame-470.jpg	files/12/1590495336751_frame-470.jpg	12	1920	1080
668	frame-461.jpg	files/12/1590495336791_frame-461.jpg	12	1920	1080
678	frame-451.jpg	files/12/1590495336856_frame-451.jpg	12	1920	1080
686	frame-443.jpg	files/12/1590495336904_frame-443.jpg	12	1920	1080
696	frame-433.jpg	files/12/1590495336972_frame-433.jpg	12	1920	1080
705	frame-424.jpg	files/12/1590495337027_frame-424.jpg	12	1920	1080
715	frame-414.jpg	files/12/1590495337090_frame-414.jpg	12	1920	1080
723	frame-406.jpg	files/12/1590495337143_frame-406.jpg	12	1920	1080
733	frame-396.jpg	files/12/1590495337203_frame-396.jpg	12	1920	1080
742	frame-387.jpg	files/12/1590495337261_frame-387.jpg	12	1920	1080
751	frame-378.jpg	files/12/1590495337325_frame-378.jpg	12	1920	1080
761	frame-368.jpg	files/12/1590495337386_frame-368.jpg	12	1920	1080
770	frame-359.jpg	files/12/1590495337445_frame-359.jpg	12	1920	1080
780	frame-349.jpg	files/12/1590495337503_frame-349.jpg	12	1920	1080
793	frame-336.jpg	files/12/1590495337586_frame-336.jpg	12	1920	1080
803	frame-326.jpg	files/12/1590495337650_frame-326.jpg	12	1920	1080
812	frame-317.jpg	files/12/1590495337708_frame-317.jpg	12	1920	1080
822	frame-307.jpg	files/12/1590495337773_frame-307.jpg	12	1920	1080
831	frame-298.jpg	files/12/1590495337828_frame-298.jpg	12	1920	1080
841	frame-288.jpg	files/12/1590495337892_frame-288.jpg	12	1920	1080
850	frame-279.jpg	files/12/1590495337948_frame-279.jpg	12	1920	1080
864	frame-265.jpg	files/12/1590495338040_frame-265.jpg	12	1920	1080
877	frame-252.jpg	files/12/1590495338123_frame-252.jpg	12	1920	1080
887	frame-242.jpg	files/12/1590495338187_frame-242.jpg	12	1920	1080
897	frame-232.jpg	files/12/1590495338248_frame-232.jpg	12	1920	1080
907	frame-222.jpg	files/12/1590495338313_frame-222.jpg	12	1920	1080
90	frame-1039.jpg	files/12/1590495333097_frame-1039.jpg	12	1920	1080
100	frame-1029.jpg	files/12/1590495333161_frame-1029.jpg	12	1920	1080
108	frame-1021.jpg	files/12/1590495333211_frame-1021.jpg	12	1920	1080
118	frame-1011.jpg	files/12/1590495333275_frame-1011.jpg	12	1920	1080
133	frame-996.jpg	files/12/1590495333371_frame-996.jpg	12	1920	1080
143	frame-987.jpg	files/12/1590495333432_frame-987.jpg	12	1920	1080
151	frame-978.jpg	files/12/1590495333557_frame-978.jpg	12	1920	1080
161	frame-966.jpg	files/12/1590495333593_frame-966.jpg	12	1920	1080
169	frame-959.jpg	files/12/1590495333611_frame-959.jpg	12	1920	1080
179	frame-951.jpg	files/12/1590495333662_frame-951.jpg	12	1920	1080
188	frame-943.jpg	files/12/1590495333714_frame-943.jpg	12	1920	1080
198	frame-934.jpg	files/12/1590495333776_frame-934.jpg	12	1920	1080
208	frame-921.jpg	files/12/1590495333855_frame-921.jpg	12	1920	1080
216	frame-913.jpg	files/12/1590495333907_frame-913.jpg	12	1920	1080
226	frame-903.jpg	files/12/1590495333987_frame-903.jpg	12	1920	1080
234	frame-896.jpg	files/12/1590495334018_frame-896.jpg	12	1920	1080
244	frame-887.jpg	files/12/1590495334075_frame-887.jpg	12	1920	1080
253	frame-878.jpg	files/12/1590495334136_frame-878.jpg	12	1920	1080
262	frame-866.jpg	files/12/1590495334210_frame-866.jpg	12	1920	1080
272	frame-857.jpg	files/12/1590495334270_frame-857.jpg	12	1920	1080
280	frame-851.jpg	files/12/1590495334307_frame-851.jpg	12	1920	1080
290	frame-839.jpg	files/12/1590495334385_frame-839.jpg	12	1920	1080
301	frame-828.jpg	files/12/1590495334461_frame-828.jpg	12	1920	1080
312	frame-817.jpg	files/12/1590495334528_frame-817.jpg	12	1920	1080
325	frame-804.jpg	files/12/1590495334608_frame-804.jpg	12	1920	1080
335	frame-793.jpg	files/12/1590495334678_frame-793.jpg	12	1920	1080
347	frame-781.jpg	files/12/1590495334755_frame-781.jpg	12	1920	1080
359	frame-771.jpg	files/12/1590495334820_frame-771.jpg	12	1920	1080
369	frame-759.jpg	files/12/1590495334905_frame-759.jpg	12	1920	1080
381	frame-748.jpg	files/12/1590495334968_frame-748.jpg	12	1920	1080
393	frame-736.jpg	files/12/1590495335042_frame-736.jpg	12	1920	1080
403	frame-726.jpg	files/12/1590495335108_frame-726.jpg	12	1920	1080
415	frame-715.jpg	files/12/1590495335182_frame-715.jpg	12	1920	1080
427	frame-702.jpg	files/12/1590495335265_frame-702.jpg	12	1920	1080
437	frame-692.jpg	files/12/1590495335326_frame-692.jpg	12	1920	1080
449	frame-680.jpg	files/12/1590495335402_frame-680.jpg	12	1920	1080
461	frame-668.jpg	files/12/1590495335480_frame-668.jpg	12	1920	1080
471	frame-658.jpg	files/12/1590495335544_frame-658.jpg	12	1920	1080
483	frame-646.jpg	files/12/1590495335629_frame-646.jpg	12	1920	1080
496	frame-633.jpg	files/12/1590495335703_frame-633.jpg	12	1920	1080
506	frame-622.jpg	files/12/1590495335771_frame-622.jpg	12	1920	1080
519	frame-610.jpg	files/12/1590495335850_frame-610.jpg	12	1920	1080
532	frame-597.jpg	files/12/1590495335942_frame-597.jpg	12	1920	1080
542	frame-588.jpg	files/12/1590495335988_frame-588.jpg	12	1920	1080
555	frame-574.jpg	files/12/1590495336078_frame-574.jpg	12	1920	1080
568	frame-561.jpg	files/12/1590495336159_frame-561.jpg	12	1920	1080
578	frame-548.jpg	files/12/1590495336243_frame-548.jpg	12	1920	1080
591	frame-538.jpg	files/12/1590495336307_frame-538.jpg	12	1920	1080
604	frame-525.jpg	files/12/1590495336387_frame-525.jpg	12	1920	1080
614	frame-515.jpg	files/12/1590495336451_frame-515.jpg	12	1920	1080
627	frame-502.jpg	files/12/1590495336533_frame-502.jpg	12	1920	1080
641	frame-488.jpg	files/12/1590495336627_frame-488.jpg	12	1920	1080
655	frame-474.jpg	files/12/1590495336748_frame-474.jpg	12	1920	1080
669	frame-460.jpg	files/12/1590495336798_frame-460.jpg	12	1920	1080
682	frame-447.jpg	files/12/1590495336880_frame-447.jpg	12	1920	1080
692	frame-437.jpg	files/12/1590495336944_frame-437.jpg	12	1920	1080
706	frame-423.jpg	files/12/1590495337033_frame-423.jpg	12	1920	1080
719	frame-410.jpg	files/12/1590495337114_frame-410.jpg	12	1920	1080
729	frame-400.jpg	files/12/1590495337178_frame-400.jpg	12	1920	1080
743	frame-386.jpg	files/12/1590495337269_frame-386.jpg	12	1920	1080
757	frame-372.jpg	files/12/1590495337359_frame-372.jpg	12	1920	1080
771	frame-358.jpg	files/12/1590495337448_frame-358.jpg	12	1920	1080
781	frame-348.jpg	files/12/1590495337509_frame-348.jpg	12	1920	1080
794	frame-335.jpg	files/12/1590495337592_frame-335.jpg	12	1920	1080
808	frame-321.jpg	files/12/1590495337684_frame-321.jpg	12	1920	1080
818	frame-311.jpg	files/12/1590495337748_frame-311.jpg	12	1920	1080
832	frame-297.jpg	files/12/1590495337834_frame-297.jpg	12	1920	1080
846	frame-283.jpg	files/12/1590495337923_frame-283.jpg	12	1920	1080
859	frame-270.jpg	files/12/1590495338009_frame-270.jpg	12	1920	1080
869	frame-260.jpg	files/12/1590495338071_frame-260.jpg	12	1920	1080
883	frame-246.jpg	files/12/1590495338162_frame-246.jpg	12	1920	1080
896	frame-233.jpg	files/12/1590495338242_frame-233.jpg	12	1920	1080
906	frame-223.jpg	files/12/1590495338306_frame-223.jpg	12	1920	1080
917	frame-212.jpg	files/12/1590495338377_frame-212.jpg	12	1920	1080
930	frame-199.jpg	files/12/1590495338460_frame-199.jpg	12	1920	1080
941	frame-188.jpg	files/12/1590495338531_frame-188.jpg	12	1920	1080
951	frame-178.jpg	files/12/1590495338594_frame-178.jpg	12	1920	1080
968	frame-161.jpg	files/12/1590495338702_frame-161.jpg	12	1920	1080
979	frame-150.jpg	files/12/1590495338772_frame-150.jpg	12	1920	1080
996	frame-133.jpg	files/12/1590495338884_frame-133.jpg	12	1920	1080
1008	frame-121.jpg	files/12/1590495338961_frame-121.jpg	12	1920	1080
91	frame-1037.jpg	files/12/1590495333110_frame-1037.jpg	12	1920	1080
101	frame-1028.jpg	files/12/1590495333168_frame-1028.jpg	12	1920	1080
116	frame-1013.jpg	files/12/1590495333260_frame-1013.jpg	12	1920	1080
126	frame-1002.jpg	files/12/1590495333331_frame-1002.jpg	12	1920	1080
136	frame-990.jpg	files/12/1590495333411_frame-990.jpg	12	1920	1080
152	frame-977.jpg	files/12/1590495333563_frame-977.jpg	12	1920	1080
162	frame-968.jpg	files/12/1590495333592_frame-968.jpg	12	1920	1080
172	frame-956.jpg	files/12/1590495333630_frame-956.jpg	12	1920	1080
182	frame-946.jpg	files/12/1590495333698_frame-946.jpg	12	1920	1080
191	frame-937.jpg	files/12/1590495333754_frame-937.jpg	12	1920	1080
201	frame-927.jpg	files/12/1590495333820_frame-927.jpg	12	1920	1080
212	frame-916.jpg	files/12/1590495333889_frame-916.jpg	12	1920	1080
221	frame-908.jpg	files/12/1590495333938_frame-908.jpg	12	1920	1080
237	frame-893.jpg	files/12/1590495334034_frame-893.jpg	12	1920	1080
248	frame-880.jpg	files/12/1590495334121_frame-880.jpg	12	1920	1080
264	frame-865.jpg	files/12/1590495334217_frame-865.jpg	12	1920	1080
274	frame-853.jpg	files/12/1590495334296_frame-853.jpg	12	1920	1080
285	frame-844.jpg	files/12/1590495334353_frame-844.jpg	12	1920	1080
296	frame-833.jpg	files/12/1590495334424_frame-833.jpg	12	1920	1080
306	frame-823.jpg	files/12/1590495334488_frame-823.jpg	12	1920	1080
316	frame-813.jpg	files/12/1590495334555_frame-813.jpg	12	1920	1080
323	frame-806.jpg	files/12/1590495334596_frame-806.jpg	12	1920	1080
333	frame-798.jpg	files/12/1590495334648_frame-798.jpg	12	1920	1080
341	frame-786.jpg	files/12/1590495334724_frame-786.jpg	12	1920	1080
351	frame-778.jpg	files/12/1590495334775_frame-778.jpg	12	1920	1080
358	frame-772.jpg	files/12/1590495334815_frame-772.jpg	12	1920	1080
368	frame-761.jpg	files/12/1590495334885_frame-761.jpg	12	1920	1080
375	frame-754.jpg	files/12/1590495334930_frame-754.jpg	12	1920	1080
385	frame-744.jpg	files/12/1590495334993_frame-744.jpg	12	1920	1080
392	frame-737.jpg	files/12/1590495335037_frame-737.jpg	12	1920	1080
402	frame-727.jpg	files/12/1590495335102_frame-727.jpg	12	1920	1080
409	frame-720.jpg	files/12/1590495335151_frame-720.jpg	12	1920	1080
419	frame-710.jpg	files/12/1590495335213_frame-710.jpg	12	1920	1080
426	frame-703.jpg	files/12/1590495335259_frame-703.jpg	12	1920	1080
436	frame-693.jpg	files/12/1590495335320_frame-693.jpg	12	1920	1080
443	frame-686.jpg	files/12/1590495335363_frame-686.jpg	12	1920	1080
453	frame-676.jpg	files/12/1590495335428_frame-676.jpg	12	1920	1080
460	frame-670.jpg	files/12/1590495335467_frame-670.jpg	12	1920	1080
470	frame-659.jpg	files/12/1590495335537_frame-659.jpg	12	1920	1080
477	frame-652.jpg	files/12/1590495335583_frame-652.jpg	12	1920	1080
487	frame-642.jpg	files/12/1590495335645_frame-642.jpg	12	1920	1080
494	frame-634.jpg	files/12/1590495335694_frame-634.jpg	12	1920	1080
504	frame-624.jpg	files/12/1590495335758_frame-624.jpg	12	1920	1080
511	frame-618.jpg	files/12/1590495335798_frame-618.jpg	12	1920	1080
521	frame-608.jpg	files/12/1590495335862_frame-608.jpg	12	1920	1080
530	frame-600.jpg	files/12/1590495335914_frame-600.jpg	12	1920	1080
540	frame-587.jpg	files/12/1590495335995_frame-587.jpg	12	1920	1080
547	frame-582.jpg	files/12/1590495336025_frame-582.jpg	12	1920	1080
557	frame-571.jpg	files/12/1590495336095_frame-571.jpg	12	1920	1080
566	frame-563.jpg	files/12/1590495336147_frame-563.jpg	12	1920	1080
576	frame-550.jpg	files/12/1590495336230_frame-550.jpg	12	1920	1080
583	frame-543.jpg	files/12/1590495336276_frame-543.jpg	12	1920	1080
593	frame-536.jpg	files/12/1590495336319_frame-536.jpg	12	1920	1080
602	frame-527.jpg	files/12/1590495336374_frame-527.jpg	12	1920	1080
612	frame-517.jpg	files/12/1590495336439_frame-517.jpg	12	1920	1080
619	frame-510.jpg	files/12/1590495336481_frame-510.jpg	12	1920	1080
629	frame-500.jpg	files/12/1590495336545_frame-500.jpg	12	1920	1080
638	frame-491.jpg	files/12/1590495336604_frame-491.jpg	12	1920	1080
647	frame-482.jpg	files/12/1590495336740_frame-482.jpg	12	1920	1080
657	frame-472.jpg	files/12/1590495336750_frame-472.jpg	12	1920	1080
666	frame-463.jpg	files/12/1590495336779_frame-463.jpg	12	1920	1080
676	frame-453.jpg	files/12/1590495336843_frame-453.jpg	12	1920	1080
684	frame-445.jpg	files/12/1590495336892_frame-445.jpg	12	1920	1080
694	frame-435.jpg	files/12/1590495336957_frame-435.jpg	12	1920	1080
703	frame-426.jpg	files/12/1590495337014_frame-426.jpg	12	1920	1080
713	frame-416.jpg	files/12/1590495337077_frame-416.jpg	12	1920	1080
721	frame-408.jpg	files/12/1590495337126_frame-408.jpg	12	1920	1080
731	frame-398.jpg	files/12/1590495337191_frame-398.jpg	12	1920	1080
740	frame-389.jpg	files/12/1590495337249_frame-389.jpg	12	1920	1080
749	frame-380.jpg	files/12/1590495337307_frame-380.jpg	12	1920	1080
759	frame-370.jpg	files/12/1590495337371_frame-370.jpg	12	1920	1080
768	frame-361.jpg	files/12/1590495337430_frame-361.jpg	12	1920	1080
778	frame-351.jpg	files/12/1590495337491_frame-351.jpg	12	1920	1080
787	frame-342.jpg	files/12/1590495337549_frame-342.jpg	12	1920	1080
796	frame-333.jpg	files/12/1590495337605_frame-333.jpg	12	1920	1080
805	frame-324.jpg	files/12/1590495337666_frame-324.jpg	12	1920	1080
815	frame-314.jpg	files/12/1590495337730_frame-314.jpg	12	1920	1080
824	frame-305.jpg	files/12/1590495337785_frame-305.jpg	12	1920	1080
834	frame-295.jpg	files/12/1590495337846_frame-295.jpg	12	1920	1080
843	frame-286.jpg	files/12/1590495337905_frame-286.jpg	12	1920	1080
853	frame-276.jpg	files/12/1590495337974_frame-276.jpg	12	1920	1080
92	frame-1038.jpg	files/12/1590495333104_frame-1038.jpg	12	1920	1080
102	frame-1027.jpg	files/12/1590495333174_frame-1027.jpg	12	1920	1080
117	frame-1012.jpg	files/12/1590495333269_frame-1012.jpg	12	1920	1080
127	frame-1005.jpg	files/12/1590495333313_frame-1005.jpg	12	1920	1080
137	frame-993.jpg	files/12/1590495333392_frame-993.jpg	12	1920	1080
153	frame-976.jpg	files/12/1590495333570_frame-976.jpg	12	1920	1080
163	frame-965.jpg	files/12/1590495333594_frame-965.jpg	12	1920	1080
173	frame-955.jpg	files/12/1590495333636_frame-955.jpg	12	1920	1080
183	frame-947.jpg	files/12/1590495333688_frame-947.jpg	12	1920	1080
193	frame-935.jpg	files/12/1590495333769_frame-935.jpg	12	1920	1080
202	frame-930.jpg	files/12/1590495333800_frame-930.jpg	12	1920	1080
210	frame-918.jpg	files/12/1590495333875_frame-918.jpg	12	1920	1080
219	frame-910.jpg	files/12/1590495333926_frame-910.jpg	12	1920	1080
228	frame-900.jpg	files/12/1590495333994_frame-900.jpg	12	1920	1080
238	frame-892.jpg	files/12/1590495334043_frame-892.jpg	12	1920	1080
246	frame-884.jpg	files/12/1590495334095_frame-884.jpg	12	1920	1080
256	frame-873.jpg	files/12/1590495334166_frame-873.jpg	12	1920	1080
265	frame-864.jpg	files/12/1590495334222_frame-864.jpg	12	1920	1080
275	frame-855.jpg	files/12/1590495334282_frame-855.jpg	12	1920	1080
283	frame-845.jpg	files/12/1590495334347_frame-845.jpg	12	1920	1080
293	frame-836.jpg	files/12/1590495334403_frame-836.jpg	12	1920	1080
295	frame-834.jpg	files/12/1590495334418_frame-834.jpg	12	1920	1080
305	frame-824.jpg	files/12/1590495334482_frame-824.jpg	12	1920	1080
315	frame-814.jpg	files/12/1590495334548_frame-814.jpg	12	1920	1080
322	frame-807.jpg	files/12/1590495334590_frame-807.jpg	12	1920	1080
332	frame-796.jpg	files/12/1590495334661_frame-796.jpg	12	1920	1080
340	frame-787.jpg	files/12/1590495334715_frame-787.jpg	12	1920	1080
350	frame-779.jpg	files/12/1590495334767_frame-779.jpg	12	1920	1080
357	frame-773.jpg	files/12/1590495334808_frame-773.jpg	12	1920	1080
367	frame-762.jpg	files/12/1590495334878_frame-762.jpg	12	1920	1080
374	frame-755.jpg	files/12/1590495334924_frame-755.jpg	12	1920	1080
384	frame-745.jpg	files/12/1590495334988_frame-745.jpg	12	1920	1080
391	frame-738.jpg	files/12/1590495335030_frame-738.jpg	12	1920	1080
401	frame-728.jpg	files/12/1590495335096_frame-728.jpg	12	1920	1080
408	frame-721.jpg	files/12/1590495335142_frame-721.jpg	12	1920	1080
418	frame-711.jpg	files/12/1590495335207_frame-711.jpg	12	1920	1080
425	frame-704.jpg	files/12/1590495335253_frame-704.jpg	12	1920	1080
435	frame-694.jpg	files/12/1590495335314_frame-694.jpg	12	1920	1080
442	frame-687.jpg	files/12/1590495335357_frame-687.jpg	12	1920	1080
452	frame-678.jpg	files/12/1590495335415_frame-678.jpg	12	1920	1080
459	frame-669.jpg	files/12/1590495335473_frame-669.jpg	12	1920	1080
469	frame-660.jpg	files/12/1590495335531_frame-660.jpg	12	1920	1080
476	frame-653.jpg	files/12/1590495335574_frame-653.jpg	12	1920	1080
486	frame-643.jpg	files/12/1590495335639_frame-643.jpg	12	1920	1080
493	frame-636.jpg	files/12/1590495335681_frame-636.jpg	12	1920	1080
503	frame-626.jpg	files/12/1590495335746_frame-626.jpg	12	1920	1080
510	frame-619.jpg	files/12/1590495335792_frame-619.jpg	12	1920	1080
520	frame-609.jpg	files/12/1590495335856_frame-609.jpg	12	1920	1080
529	frame-601.jpg	files/12/1590495335908_frame-601.jpg	12	1920	1080
539	frame-590.jpg	files/12/1590495335976_frame-590.jpg	12	1920	1080
546	frame-584.jpg	files/12/1590495336013_frame-584.jpg	12	1920	1080
556	frame-573.jpg	files/12/1590495336083_frame-573.jpg	12	1920	1080
565	frame-564.jpg	files/12/1590495336141_frame-564.jpg	12	1920	1080
575	frame-551.jpg	files/12/1590495336224_frame-551.jpg	12	1920	1080
582	frame-544.jpg	files/12/1590495336270_frame-544.jpg	12	1920	1080
592	frame-537.jpg	files/12/1590495336313_frame-537.jpg	12	1920	1080
601	frame-528.jpg	files/12/1590495336368_frame-528.jpg	12	1920	1080
611	frame-518.jpg	files/12/1590495336434_frame-518.jpg	12	1920	1080
618	frame-511.jpg	files/12/1590495336475_frame-511.jpg	12	1920	1080
628	frame-501.jpg	files/12/1590495336540_frame-501.jpg	12	1920	1080
637	frame-492.jpg	files/12/1590495336598_frame-492.jpg	12	1920	1080
646	frame-483.jpg	files/12/1590495336656_frame-483.jpg	12	1920	1080
656	frame-473.jpg	files/12/1590495336749_frame-473.jpg	12	1920	1080
665	frame-464.jpg	files/12/1590495336773_frame-464.jpg	12	1920	1080
675	frame-454.jpg	files/12/1590495336836_frame-454.jpg	12	1920	1080
683	frame-446.jpg	files/12/1590495336886_frame-446.jpg	12	1920	1080
693	frame-436.jpg	files/12/1590495336950_frame-436.jpg	12	1920	1080
702	frame-427.jpg	files/12/1590495337009_frame-427.jpg	12	1920	1080
712	frame-417.jpg	files/12/1590495337071_frame-417.jpg	12	1920	1080
720	frame-409.jpg	files/12/1590495337120_frame-409.jpg	12	1920	1080
730	frame-399.jpg	files/12/1590495337185_frame-399.jpg	12	1920	1080
739	frame-390.jpg	files/12/1590495337243_frame-390.jpg	12	1920	1080
748	frame-381.jpg	files/12/1590495337301_frame-381.jpg	12	1920	1080
758	frame-371.jpg	files/12/1590495337365_frame-371.jpg	12	1920	1080
767	frame-362.jpg	files/12/1590495337424_frame-362.jpg	12	1920	1080
777	frame-352.jpg	files/12/1590495337485_frame-352.jpg	12	1920	1080
786	frame-343.jpg	files/12/1590495337543_frame-343.jpg	12	1920	1080
795	frame-334.jpg	files/12/1590495337599_frame-334.jpg	12	1920	1080
804	frame-325.jpg	files/12/1590495337656_frame-325.jpg	12	1920	1080
814	frame-315.jpg	files/12/1590495337724_frame-315.jpg	12	1920	1080
823	frame-306.jpg	files/12/1590495337779_frame-306.jpg	12	1920	1080
819	frame-310.jpg	files/12/1590495337755_frame-310.jpg	12	1920	1080
828	frame-301.jpg	files/12/1590495337810_frame-301.jpg	12	1920	1080
838	frame-291.jpg	files/12/1590495337874_frame-291.jpg	12	1920	1080
847	frame-282.jpg	files/12/1590495337930_frame-282.jpg	12	1920	1080
856	frame-273.jpg	files/12/1590495338005_frame-273.jpg	12	1920	1080
866	frame-263.jpg	files/12/1590495338052_frame-263.jpg	12	1920	1080
874	frame-255.jpg	files/12/1590495338104_frame-255.jpg	12	1920	1080
884	frame-245.jpg	files/12/1590495338168_frame-245.jpg	12	1920	1080
891	frame-238.jpg	files/12/1590495338212_frame-238.jpg	12	1920	1080
901	frame-228.jpg	files/12/1590495338273_frame-228.jpg	12	1920	1080
909	frame-220.jpg	files/12/1590495338325_frame-220.jpg	12	1920	1080
919	frame-210.jpg	files/12/1590495338389_frame-210.jpg	12	1920	1080
924	frame-205.jpg	files/12/1590495338420_frame-205.jpg	12	1920	1080
934	frame-195.jpg	files/12/1590495338487_frame-195.jpg	12	1920	1080
943	frame-186.jpg	files/12/1590495338542_frame-186.jpg	12	1920	1080
953	frame-176.jpg	files/12/1590495338608_frame-176.jpg	12	1920	1080
962	frame-167.jpg	files/12/1590495338662_frame-167.jpg	12	1920	1080
971	frame-158.jpg	files/12/1590495338720_frame-158.jpg	12	1920	1080
981	frame-148.jpg	files/12/1590495338785_frame-148.jpg	12	1920	1080
988	frame-141.jpg	files/12/1590495338831_frame-141.jpg	12	1920	1080
998	frame-131.jpg	files/12/1590495338895_frame-131.jpg	12	1920	1080
1005	frame-124.jpg	files/12/1590495338941_frame-124.jpg	12	1920	1080
1015	frame-114.jpg	files/12/1590495339002_frame-114.jpg	12	1920	1080
1022	frame-107.jpg	files/12/1590495339048_frame-107.jpg	12	1920	1080
1032	frame-097.jpg	files/12/1590495339112_frame-097.jpg	12	1920	1080
1040	frame-089.jpg	files/12/1590495339162_frame-089.jpg	12	1920	1080
1050	frame-079.jpg	files/12/1590495339227_frame-079.jpg	12	1920	1080
1057	frame-072.jpg	files/12/1590495339272_frame-072.jpg	12	1920	1080
1067	frame-062.jpg	files/12/1590495339334_frame-062.jpg	12	1920	1080
1075	frame-054.jpg	files/12/1590495339387_frame-054.jpg	12	1920	1080
1085	frame-044.jpg	files/12/1590495339450_frame-044.jpg	12	1920	1080
1094	frame-035.jpg	files/12/1590495339508_frame-035.jpg	12	1920	1080
1104	frame-025.jpg	files/12/1590495339571_frame-025.jpg	12	1920	1080
1111	frame-018.jpg	files/12/1590495339614_frame-018.jpg	12	1920	1080
1121	frame-008.jpg	files/12/1590495339680_frame-008.jpg	12	1920	1080
820	frame-309.jpg	files/12/1590495337761_frame-309.jpg	12	1920	1080
829	frame-300.jpg	files/12/1590495337816_frame-300.jpg	12	1920	1080
839	frame-290.jpg	files/12/1590495337880_frame-290.jpg	12	1920	1080
848	frame-281.jpg	files/12/1590495337935_frame-281.jpg	12	1920	1080
857	frame-272.jpg	files/12/1590495338006_frame-272.jpg	12	1920	1080
867	frame-262.jpg	files/12/1590495338058_frame-262.jpg	12	1920	1080
875	frame-254.jpg	files/12/1590495338110_frame-254.jpg	12	1920	1080
885	frame-244.jpg	files/12/1590495338175_frame-244.jpg	12	1920	1080
892	frame-237.jpg	files/12/1590495338217_frame-237.jpg	12	1920	1080
902	frame-227.jpg	files/12/1590495338282_frame-227.jpg	12	1920	1080
912	frame-217.jpg	files/12/1590495338343_frame-217.jpg	12	1920	1080
922	frame-207.jpg	files/12/1590495338407_frame-207.jpg	12	1920	1080
931	frame-198.jpg	files/12/1590495338469_frame-198.jpg	12	1920	1080
940	frame-189.jpg	files/12/1590495338524_frame-189.jpg	12	1920	1080
950	frame-179.jpg	files/12/1590495338588_frame-179.jpg	12	1920	1080
959	frame-170.jpg	files/12/1590495338644_frame-170.jpg	12	1920	1080
969	frame-160.jpg	files/12/1590495338708_frame-160.jpg	12	1920	1080
976	frame-153.jpg	files/12/1590495338751_frame-153.jpg	12	1920	1080
986	frame-143.jpg	files/12/1590495338819_frame-143.jpg	12	1920	1080
993	frame-136.jpg	files/12/1590495338864_frame-136.jpg	12	1920	1080
1003	frame-126.jpg	files/12/1590495338929_frame-126.jpg	12	1920	1080
1010	frame-119.jpg	files/12/1590495338972_frame-119.jpg	12	1920	1080
1020	frame-109.jpg	files/12/1590495339035_frame-109.jpg	12	1920	1080
1028	frame-101.jpg	files/12/1590495339085_frame-101.jpg	12	1920	1080
1038	frame-091.jpg	files/12/1590495339150_frame-091.jpg	12	1920	1080
1045	frame-084.jpg	files/12/1590495339196_frame-084.jpg	12	1920	1080
1055	frame-074.jpg	files/12/1590495339260_frame-074.jpg	12	1920	1080
1062	frame-067.jpg	files/12/1590495339303_frame-067.jpg	12	1920	1080
1072	frame-057.jpg	files/12/1590495339364_frame-057.jpg	12	1920	1080
1082	frame-047.jpg	files/12/1590495339429_frame-047.jpg	12	1920	1080
1090	frame-039.jpg	files/12/1590495339481_frame-039.jpg	12	1920	1080
1098	frame-031.jpg	files/12/1590495339533_frame-031.jpg	12	1920	1080
1108	frame-021.jpg	files/12/1590495339595_frame-021.jpg	12	1920	1080
1117	frame-012.jpg	files/12/1590495339654_frame-012.jpg	12	1920	1080
1125	frame-004.jpg	files/12/1590495339721_frame-004.jpg	12	1920	1080
833	frame-296.jpg	files/12/1590495337840_frame-296.jpg	12	1920	1080
842	frame-287.jpg	files/12/1590495337899_frame-287.jpg	12	1920	1080
852	frame-277.jpg	files/12/1590495337963_frame-277.jpg	12	1920	1080
860	frame-269.jpg	files/12/1590495338013_frame-269.jpg	12	1920	1080
870	frame-259.jpg	files/12/1590495338076_frame-259.jpg	12	1920	1080
879	frame-250.jpg	files/12/1590495338135_frame-250.jpg	12	1920	1080
889	frame-240.jpg	files/12/1590495338200_frame-240.jpg	12	1920	1080
898	frame-231.jpg	files/12/1590495338254_frame-231.jpg	12	1920	1080
910	frame-219.jpg	files/12/1590495338331_frame-219.jpg	12	1920	1080
920	frame-209.jpg	files/12/1590495338395_frame-209.jpg	12	1920	1080
925	frame-204.jpg	files/12/1590495338432_frame-204.jpg	12	1920	1080
935	frame-194.jpg	files/12/1590495338493_frame-194.jpg	12	1920	1080
944	frame-185.jpg	files/12/1590495338549_frame-185.jpg	12	1920	1080
954	frame-175.jpg	files/12/1590495338613_frame-175.jpg	12	1920	1080
963	frame-166.jpg	files/12/1590495338668_frame-166.jpg	12	1920	1080
972	frame-157.jpg	files/12/1590495338728_frame-157.jpg	12	1920	1080
982	frame-147.jpg	files/12/1590495338791_frame-147.jpg	12	1920	1080
989	frame-140.jpg	files/12/1590495338838_frame-140.jpg	12	1920	1080
999	frame-130.jpg	files/12/1590495338902_frame-130.jpg	12	1920	1080
1006	frame-123.jpg	files/12/1590495338947_frame-123.jpg	12	1920	1080
1016	frame-113.jpg	files/12/1590495339009_frame-113.jpg	12	1920	1080
1023	frame-106.jpg	files/12/1590495339054_frame-106.jpg	12	1920	1080
1033	frame-096.jpg	files/12/1590495339117_frame-096.jpg	12	1920	1080
1041	frame-088.jpg	files/12/1590495339168_frame-088.jpg	12	1920	1080
1051	frame-078.jpg	files/12/1590495339232_frame-078.jpg	12	1920	1080
1058	frame-071.jpg	files/12/1590495339279_frame-071.jpg	12	1920	1080
1068	frame-061.jpg	files/12/1590495339340_frame-061.jpg	12	1920	1080
1076	frame-053.jpg	files/12/1590495339392_frame-053.jpg	12	1920	1080
1086	frame-043.jpg	files/12/1590495339456_frame-043.jpg	12	1920	1080
1095	frame-034.jpg	files/12/1590495339514_frame-034.jpg	12	1920	1080
1105	frame-024.jpg	files/12/1590495339577_frame-024.jpg	12	1920	1080
1112	frame-017.jpg	files/12/1590495339619_frame-017.jpg	12	1920	1080
1122	frame-007.jpg	files/12/1590495339687_frame-007.jpg	12	1920	1080
854	frame-275.jpg	files/12/1590495337975_frame-275.jpg	12	1920	1080
862	frame-267.jpg	files/12/1590495338025_frame-267.jpg	12	1920	1080
872	frame-257.jpg	files/12/1590495338095_frame-257.jpg	12	1920	1080
881	frame-248.jpg	files/12/1590495338150_frame-248.jpg	12	1920	1080
890	frame-239.jpg	files/12/1590495338206_frame-239.jpg	12	1920	1080
900	frame-229.jpg	files/12/1590495338267_frame-229.jpg	12	1920	1080
908	frame-221.jpg	files/12/1590495338319_frame-221.jpg	12	1920	1080
918	frame-211.jpg	files/12/1590495338383_frame-211.jpg	12	1920	1080
923	frame-206.jpg	files/12/1590495338414_frame-206.jpg	12	1920	1080
933	frame-196.jpg	files/12/1590495338481_frame-196.jpg	12	1920	1080
942	frame-187.jpg	files/12/1590495338536_frame-187.jpg	12	1920	1080
952	frame-177.jpg	files/12/1590495338600_frame-177.jpg	12	1920	1080
961	frame-168.jpg	files/12/1590495338657_frame-168.jpg	12	1920	1080
970	frame-159.jpg	files/12/1590495338714_frame-159.jpg	12	1920	1080
980	frame-149.jpg	files/12/1590495338778_frame-149.jpg	12	1920	1080
987	frame-142.jpg	files/12/1590495338825_frame-142.jpg	12	1920	1080
997	frame-132.jpg	files/12/1590495338889_frame-132.jpg	12	1920	1080
1004	frame-125.jpg	files/12/1590495338935_frame-125.jpg	12	1920	1080
1014	frame-115.jpg	files/12/1590495338997_frame-115.jpg	12	1920	1080
1021	frame-108.jpg	files/12/1590495339039_frame-108.jpg	12	1920	1080
1031	frame-098.jpg	files/12/1590495339104_frame-098.jpg	12	1920	1080
1039	frame-090.jpg	files/12/1590495339156_frame-090.jpg	12	1920	1080
1049	frame-080.jpg	files/12/1590495339223_frame-080.jpg	12	1920	1080
1056	frame-073.jpg	files/12/1590495339266_frame-073.jpg	12	1920	1080
1066	frame-063.jpg	files/12/1590495339328_frame-063.jpg	12	1920	1080
1074	frame-055.jpg	files/12/1590495339382_frame-055.jpg	12	1920	1080
1084	frame-045.jpg	files/12/1590495339441_frame-045.jpg	12	1920	1080
1093	frame-036.jpg	files/12/1590495339499_frame-036.jpg	12	1920	1080
1103	frame-026.jpg	files/12/1590495339564_frame-026.jpg	12	1920	1080
1110	frame-019.jpg	files/12/1590495339608_frame-019.jpg	12	1920	1080
1120	frame-009.jpg	files/12/1590495339672_frame-009.jpg	12	1920	1080
861	frame-268.jpg	files/12/1590495338021_frame-268.jpg	12	1920	1080
871	frame-258.jpg	files/12/1590495338086_frame-258.jpg	12	1920	1080
880	frame-249.jpg	files/12/1590495338144_frame-249.jpg	12	1920	1080
893	frame-236.jpg	files/12/1590495338225_frame-236.jpg	12	1920	1080
903	frame-226.jpg	files/12/1590495338288_frame-226.jpg	12	1920	1080
913	frame-216.jpg	files/12/1590495338349_frame-216.jpg	12	1920	1080
926	frame-203.jpg	files/12/1590495338435_frame-203.jpg	12	1920	1080
936	frame-193.jpg	files/12/1590495338500_frame-193.jpg	12	1920	1080
945	frame-184.jpg	files/12/1590495338555_frame-184.jpg	12	1920	1080
955	frame-174.jpg	files/12/1590495338619_frame-174.jpg	12	1920	1080
964	frame-165.jpg	files/12/1590495338674_frame-165.jpg	12	1920	1080
973	frame-156.jpg	files/12/1590495338732_frame-156.jpg	12	1920	1080
983	frame-146.jpg	files/12/1590495338797_frame-146.jpg	12	1920	1080
990	frame-139.jpg	files/12/1590495338843_frame-139.jpg	12	1920	1080
1000	frame-129.jpg	files/12/1590495338908_frame-129.jpg	12	1920	1080
1011	frame-118.jpg	files/12/1590495338978_frame-118.jpg	12	1920	1080
1025	frame-104.jpg	files/12/1590495339067_frame-104.jpg	12	1920	1080
1035	frame-094.jpg	files/12/1590495339131_frame-094.jpg	12	1920	1080
1046	frame-083.jpg	files/12/1590495339202_frame-083.jpg	12	1920	1080
1059	frame-070.jpg	files/12/1590495339285_frame-070.jpg	12	1920	1080
1069	frame-060.jpg	files/12/1590495339346_frame-060.jpg	12	1920	1080
1077	frame-052.jpg	files/12/1590495339398_frame-052.jpg	12	1920	1080
1087	frame-042.jpg	files/12/1590495339462_frame-042.jpg	12	1920	1080
1096	frame-033.jpg	files/12/1590495339521_frame-033.jpg	12	1920	1080
1106	frame-023.jpg	files/12/1590495339583_frame-023.jpg	12	1920	1080
1113	frame-016.jpg	files/12/1590495339628_frame-016.jpg	12	1920	1080
1123	frame-006.jpg	files/12/1590495339696_frame-006.jpg	12	1920	1080
876	frame-253.jpg	files/12/1590495338117_frame-253.jpg	12	1920	1080
886	frame-243.jpg	files/12/1590495338181_frame-243.jpg	12	1920	1080
894	frame-235.jpg	files/12/1590495338229_frame-235.jpg	12	1920	1080
904	frame-225.jpg	files/12/1590495338294_frame-225.jpg	12	1920	1080
914	frame-215.jpg	files/12/1590495338355_frame-215.jpg	12	1920	1080
927	frame-202.jpg	files/12/1590495338441_frame-202.jpg	12	1920	1080
937	frame-192.jpg	files/12/1590495338508_frame-192.jpg	12	1920	1080
946	frame-183.jpg	files/12/1590495338561_frame-183.jpg	12	1920	1080
956	frame-173.jpg	files/12/1590495338625_frame-173.jpg	12	1920	1080
965	frame-164.jpg	files/12/1590495338682_frame-164.jpg	12	1920	1080
974	frame-155.jpg	files/12/1590495338738_frame-155.jpg	12	1920	1080
984	frame-145.jpg	files/12/1590495338803_frame-145.jpg	12	1920	1080
994	frame-135.jpg	files/12/1590495338870_frame-135.jpg	12	1920	1080
1007	frame-122.jpg	files/12/1590495338954_frame-122.jpg	12	1920	1080
1017	frame-112.jpg	files/12/1590495339015_frame-112.jpg	12	1920	1080
1024	frame-105.jpg	files/12/1590495339061_frame-105.jpg	12	1920	1080
1034	frame-095.jpg	files/12/1590495339122_frame-095.jpg	12	1920	1080
1042	frame-087.jpg	files/12/1590495339174_frame-087.jpg	12	1920	1080
1052	frame-077.jpg	files/12/1590495339238_frame-077.jpg	12	1920	1080
1063	frame-066.jpg	files/12/1590495339309_frame-066.jpg	12	1920	1080
1073	frame-056.jpg	files/12/1590495339374_frame-056.jpg	12	1920	1080
1083	frame-046.jpg	files/12/1590495339435_frame-046.jpg	12	1920	1080
1097	frame-032.jpg	files/12/1590495339527_frame-032.jpg	12	1920	1080
1107	frame-022.jpg	files/12/1590495339589_frame-022.jpg	12	1920	1080
1119	frame-010.jpg	files/12/1590495339665_frame-010.jpg	12	1920	1080
915	frame-214.jpg	files/12/1590495338364_frame-214.jpg	12	1920	1080
928	frame-201.jpg	files/12/1590495338459_frame-201.jpg	12	1920	1080
938	frame-191.jpg	files/12/1590495338512_frame-191.jpg	12	1920	1080
947	frame-182.jpg	files/12/1590495338567_frame-182.jpg	12	1920	1080
957	frame-172.jpg	files/12/1590495338632_frame-172.jpg	12	1920	1080
966	frame-163.jpg	files/12/1590495338691_frame-163.jpg	12	1920	1080
978	frame-151.jpg	files/12/1590495338766_frame-151.jpg	12	1920	1080
992	frame-137.jpg	files/12/1590495338858_frame-137.jpg	12	1920	1080
1002	frame-127.jpg	files/12/1590495338920_frame-127.jpg	12	1920	1080
1012	frame-117.jpg	files/12/1590495338984_frame-117.jpg	12	1920	1080
1026	frame-103.jpg	files/12/1590495339073_frame-103.jpg	12	1920	1080
1036	frame-093.jpg	files/12/1590495339137_frame-093.jpg	12	1920	1080
1047	frame-082.jpg	files/12/1590495339208_frame-082.jpg	12	1920	1080
1060	frame-069.jpg	files/12/1590495339291_frame-069.jpg	12	1920	1080
1070	frame-059.jpg	files/12/1590495339352_frame-059.jpg	12	1920	1080
1078	frame-051.jpg	files/12/1590495339404_frame-051.jpg	12	1920	1080
1088	frame-041.jpg	files/12/1590495339469_frame-041.jpg	12	1920	1080
1102	frame-027.jpg	files/12/1590495339558_frame-027.jpg	12	1920	1080
1116	frame-013.jpg	files/12/1590495339649_frame-013.jpg	12	1920	1080
1128	frame-001.jpg	files/12/1590495339782_frame-001.jpg	12	1920	1080
1018	frame-111.jpg	files/12/1590495339022_frame-111.jpg	12	1920	1080
1029	frame-100.jpg	files/12/1590495339092_frame-100.jpg	12	1920	1080
1043	frame-086.jpg	files/12/1590495339183_frame-086.jpg	12	1920	1080
1053	frame-076.jpg	files/12/1590495339248_frame-076.jpg	12	1920	1080
1065	frame-064.jpg	files/12/1590495339322_frame-064.jpg	12	1920	1080
1081	frame-048.jpg	files/12/1590495339423_frame-048.jpg	12	1920	1080
1092	frame-037.jpg	files/12/1590495339494_frame-037.jpg	12	1920	1080
1100	frame-029.jpg	files/12/1590495339546_frame-029.jpg	12	1920	1080
1114	frame-015.jpg	files/12/1590495339635_frame-015.jpg	12	1920	1080
1124	frame-005.jpg	files/12/1590495339708_frame-005.jpg	12	1920	1080
1027	frame-102.jpg	files/12/1590495339079_frame-102.jpg	12	1920	1080
1037	frame-092.jpg	files/12/1590495339145_frame-092.jpg	12	1920	1080
1048	frame-081.jpg	files/12/1590495339214_frame-081.jpg	12	1920	1080
1061	frame-068.jpg	files/12/1590495339297_frame-068.jpg	12	1920	1080
1071	frame-058.jpg	files/12/1590495339358_frame-058.jpg	12	1920	1080
1079	frame-050.jpg	files/12/1590495339410_frame-050.jpg	12	1920	1080
1089	frame-040.jpg	files/12/1590495339475_frame-040.jpg	12	1920	1080
1101	frame-028.jpg	files/12/1590495339552_frame-028.jpg	12	1920	1080
1115	frame-014.jpg	files/12/1590495339641_frame-014.jpg	12	1920	1080
1127	frame-002.jpg	files/12/1590495339766_frame-002.jpg	12	1920	1080
1030	frame-099.jpg	files/12/1590495339097_frame-099.jpg	12	1920	1080
1044	frame-085.jpg	files/12/1590495339189_frame-085.jpg	12	1920	1080
1054	frame-075.jpg	files/12/1590495339254_frame-075.jpg	12	1920	1080
1064	frame-065.jpg	files/12/1590495339315_frame-065.jpg	12	1920	1080
1080	frame-049.jpg	files/12/1590495339417_frame-049.jpg	12	1920	1080
1091	frame-038.jpg	files/12/1590495339487_frame-038.jpg	12	1920	1080
1099	frame-030.jpg	files/12/1590495339539_frame-030.jpg	12	1920	1080
1109	frame-020.jpg	files/12/1590495339602_frame-020.jpg	12	1920	1080
1118	frame-011.jpg	files/12/1590495339659_frame-011.jpg	12	1920	1080
1126	frame-003.jpg	files/12/1590495339738_frame-003.jpg	12	1920	1080
\.


--
-- Data for Name: labelings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.labelings (id, startx, starty, endx, endy, labelid, imageid) FROM stdin;
27	466	716	881	1041	12	22
29	777	672	1129	811	12	22
30	710	727	1118	967	12	1126
31	842	713	1095	845	12	1126
32	701	730	1109	949	12	1118
33	836	721	1099	848	12	1118
34	660	463	989	805	12	1109
35	743	752	1099	857	12	1109
36	710	727	1097	858	12	1099
37	850	161	1239	476	12	1099
38	1074	407	1495	650	12	1091
39	736	697	1100	859	12	1091
40	875	687	1294	907	12	1080
41	739	708	1107	844	12	1064
42	511	412	826	748	12	1064
43	809	167	1227	464	12	1054
44	741	658	1111	851	12	1054
45	1225	405	1651	647	12	1044
46	756	692	1120	860	12	1044
47	896	676	1331	906	12	1030
48	744	714	930	852	12	1030
49	714	739	1117	950	12	1127
50	720	713	1110	949	12	1115
51	737	707	1104	858	12	1101
52	758	121	1113	467	12	1101
53	1092	484	1502	720	12	1089
54	724	659	1105	862	12	1089
55	837	682	1259	919	12	1079
56	594	680	1014	925	12	1071
57	742	696	1113	851	12	1061
58	577	197	821	590	12	1061
59	752	697	1111	855	12	1048
60	1129	321	1571	542	12	1048
61	1177	587	1597	820	12	1037
62	749	673	1105	853	12	1037
63	799	683	1214	920	12	1027
64	714	732	1114	952	12	1124
65	724	702	1113	952	12	1114
66	723	702	1098	856	12	1100
67	801	137	1172	463	12	1100
68	1069	373	1465	612	12	1092
69	731	690	1101	863	12	1092
70	900	674	1320	901	12	1081
71	745	690	1105	847	12	1065
72	490	475	833	798	12	1065
73	730	677	1114	863	12	1053
74	880	198	1304	477	12	1053
75	1235	456	1670	677	12	1043
76	755	692	1117	862	12	1043
77	877	684	1290	905	12	1029
78	555	545	916	835	12	1018
79	736	716	1105	854	12	1018
80	715	734	1104	947	12	1128
81	704	730	1117	949	12	1116
82	719	713	1098	855	12	1102
83	726	114	1055	477	12	1102
84	1089	522	1496	759	12	1088
85	736	676	1104	863	12	1088
86	807	685	1229	921	12	1078
87	562	661	980	906	12	1070
88	734	700	1111	858	12	1060
89	585	143	825	527	12	1060
90	1166	352	1587	562	12	1047
91	751	695	1111	856	12	1047
92	1138	605	1561	839	12	1036
93	742	693	1111	859	12	1036
94	753	692	1199	909	12	1026
95	738	712	1120	872	12	1012
96	595	202	860	557	12	1012
97	735	654	1110	866	12	1002
98	949	152	1364	405	12	1002
99	1134	387	1569	608	12	992
100	733	677	1116	861	12	992
101	980	650	1396	857	12	978
102	745	684	988	846	12	978
103	647	678	1065	909	12	966
104	740	703	1109	853	12	957
105	436	448	758	774	12	957
106	745	684	1130	861	12	947
107	724	59	1078	376	12	947
108	1180	240	1620	461	12	938
109	731	711	1119	863	12	938
110	741	677	1124	867	12	928
111	1230	522	1656	768	12	928
112	762	675	1183	904	12	915
113	709	729	1116	950	12	1119
114	702	723	1098	859	12	1107
115	658	330	953	674	12	1107
116	733	704	1106	860	12	1097
117	955	241	1354	505	12	1097
118	972	654	1393	876	12	1083
119	741	693	1003	859	12	1083
120	657	691	1070	930	12	1073
121	731	707	1115	851	12	1063
122	501	319	808	690	12	1063
123	961	230	1386	494	12	1052
124	733	700	1117	859	12	1052
125	736	660	1126	860	12	1042
126	1226	501	1668	739	12	1042
127	1077	618	1501	863	12	1034
128	743	664	1100	855	12	1034
129	694	670	1113	920	12	1024
130	532	484	900	824	12	1017
131	758	707	1104	856	12	1017
132	737	666	1115	865	12	1007
133	720	69	1080	415	12	1007
134	1117	348	1575	540	12	994
135	721	657	1121	866	12	994
136	1081	600	1491	817	12	984
137	740	691	1108	884	12	984
138	869	688	1281	896	12	974
139	582	648	1020	913	12	965
140	433	369	778	739	12	956
141	749	707	1117	909	12	956
142	736	671	1117	878	12	946
143	746	63	1137	370	12	946
144	742	670	1137	877	12	937
145	1187	261	1651	493	12	937
146	732	641	1131	883	12	927
147	1204	510	1630	806	12	927
148	727	629	1145	909	12	914
149	726	657	1115	854	12	904
150	486	643	874	913	12	904
151	730	681	1126	870	12	894
152	483	258	793	634	12	894
153	737	666	1135	866	12	886
154	764	87	1164	418	12	886
155	734	656	1116	867	12	876
156	1144	300	1566	544	12	876
157	690	716	1117	945	12	1123
158	782	689	1098	844	12	1123
159	723	663	1113	945	12	1113
160	710	684	1109	867	12	1106
161	664	258	959	630	12	1106
162	719	644	1111	868	12	1096
163	995	256	1408	538	12	1096
164	1053	526	1490	796	12	1087
165	729	666	1100	883	12	1087
166	759	682	1196	944	12	1077
167	547	631	953	891	12	1069
168	745	658	1111	851	12	1069
169	704	693	1112	860	12	1059
170	578	83	884	489	12	1059
171	742	697	1126	864	12	1046
172	1185	357	1622	593	12	1046
173	753	671	1110	861	12	1035
174	1103	605	1534	849	12	1035
175	725	674	1142	922	12	1025
176	728	707	1113	868	12	1011
177	607	122	888	524	12	1011
178	724	670	1114	859	12	1000
179	1014	170	1446	438	12	1000
180	1130	438	1561	675	12	990
181	738	642	1117	864	12	990
182	1058	594	1478	834	12	983
183	755	654	1105	854	12	983
184	844	666	1269	898	12	973
185	571	633	994	900	12	964
186	757	654	1121	851	12	964
187	707	696	1124	852	12	955
188	456	346	766	697	12	955
189	742	692	1138	873	12	945
190	795	68	1235	374	12	945
191	736	669	1123	871	12	936
192	1229	266	1667	528	12	936
193	746	666	1118	866	12	926
194	1161	542	1591	806	12	926
195	691	674	1110	903	12	913
196	749	648	1109	857	12	903
197	463	623	852	897	12	903
200	757	683	1185	908	12	23
201	480	723	865	1023	12	24
204	475	657	869	993	12	26
206	480	712	870	1017	12	25
208	771	665	1128	813	12	24
209	771	673	1129	809	12	26
210	773	693	1129	809	12	25
211	499	639	898	958	12	27
212	786	704	1128	813	12	27
213	533	623	922	943	12	29
214	797	684	1124	817	12	29
215	493	673	873	972	12	28
216	784	674	1126	813	12	28
217	572	628	961	917	12	30
218	789	682	1126	817	12	30
219	688	659	1116	899	12	31
220	629	626	1027	913	12	32
221	823	672	1260	912	12	33
222	973	708	1408	894	12	35
224	896	694	1337	901	12	34
225	968	698	1405	891	12	36
226	767	684	1132	822	12	37
228	1083	652	1518	848	12	37
229	765	680	1145	833	12	38
230	1050	702	1482	876	12	38
232	754	672	1129	817	12	40
233	1150	593	1562	793	12	40
234	765	680	1126	817	12	39
235	1141	648	1543	814	12	39
236	762	688	1124	819	12	41
237	1171	516	1576	708	12	41
239	765	707	1124	820	12	42
240	1176	579	1568	757	12	42
241	776	702	1123	823	12	45
243	1135	319	1546	521	12	45
244	758	694	1122	822	12	44
245	1165	381	1563	573	12	44
246	769	700	1126	822	12	43
247	1165	444	1569	638	12	43
248	767	699	1130	820	12	46
249	1112	265	1515	470	12	46
250	768	700	1126	820	12	47
251	1071	200	1472	420	12	47
252	778	708	1129	820	12	48
253	1018	165	1430	390	12	48
254	775	694	1127	822	12	49
255	861	72	1284	357	12	49
256	775	708	1124	817	12	50
257	933	112	1356	364	12	50
259	765	685	1130	822	12	51
260	804	65	1210	360	12	51
261	762	704	1130	817	12	52
262	753	68	1130	372	12	52
263	759	700	1126	820	12	53
264	743	77	1066	391	12	53
265	767	695	1128	820	12	54
266	703	95	1022	439	12	54
267	760	690	1129	823	12	55
268	664	140	991	479	12	55
269	768	694	1124	832	12	56
270	629	187	935	524	12	56
271	770	688	1126	823	12	57
272	600	229	897	575	12	57
273	767	694	1127	819	12	58
274	566	264	875	615	12	58
275	771	694	1127	828	12	59
276	539	314	851	658	12	59
277	771	687	1128	823	12	60
278	522	357	837	693	12	60
279	515	443	850	773	12	61
280	782	628	1124	817	12	61
281	508	399	837	734	12	62
282	763	703	1129	823	12	62
283	515	483	861	799	12	63
284	789	687	1128	822	12	63
285	534	533	885	814	12	64
286	762	677	1140	822	12	64
287	543	551	916	837	12	65
288	801	680	1128	814	12	65
289	569	594	942	844	12	66
290	809	683	1127	814	12	66
291	589	630	973	849	12	67
292	835	694	1126	819	12	67
293	619	625	1001	840	12	68
294	647	633	1034	853	12	69
295	688	633	1082	854	12	70
296	721	640	1118	850	12	71
297	757	655	1151	858	12	72
298	828	658	1260	867	12	73
299	791	649	1212	862	12	74
300	884	663	1315	855	12	75
301	941	662	1349	852	12	76
302	1063	633	1496	814	12	77
303	763	698	1139	829	12	77
304	983	646	1410	839	12	78
305	767	685	1093	824	12	78
306	765	679	1115	819	12	79
307	1091	594	1509	784	12	79
308	770	673	1113	817	12	80
309	1032	641	1448	825	12	80
310	771	645	1123	824	12	81
311	1139	600	1537	777	12	81
312	768	644	1124	822	12	82
315	1160	584	1553	764	12	82
316	756	633	1120	820	12	83
317	1160	543	1570	747	12	83
319	760	683	1124	818	12	99
320	847	121	1244	402	12	99
321	776	674	1121	820	12	110
322	544	210	824	558	12	110
323	613	611	989	854	12	120
324	823	685	1117	812	12	120
325	754	680	1111	817	12	134
327	1159	548	1569	787	12	134
328	749	679	1113	823	12	144
329	1109	306	1502	513	12	144
330	757	688	1116	818	12	154
331	737	51	1080	376	12	154
332	618	561	1010	815	12	170
333	752	693	1109	823	12	180
334	1022	641	1438	839	12	180
335	749	687	1107	822	12	190
336	1220	459	1623	630	12	190
337	749	698	1102	817	12	200
338	843	135	1236	407	12	200
339	747	690	1101	820	12	211
340	558	60	830	436	12	211
341	751	683	1102	822	12	220
342	399	536	756	829	12	220
343	753	692	1101	825	12	236
345	1083	613	1487	815	12	236
346	749	692	1101	825	12	247
348	1221	449	1613	610	12	247
349	742	689	1098	830	12	257
350	973	186	1350	411	12	257
351	613	137	901	480	12	266
352	747	684	1099	825	12	266
353	538	618	922	864	12	281
354	760	672	1099	822	12	281
358	945	670	1361	850	12	291
359	748	700	1091	823	12	302
362	1267	496	1689	705	12	302
363	747	694	1106	835	12	313
364	1066	219	1458	431	12	313
365	752	695	1100	837	12	326
366	596	127	868	484	12	326
368	563	550	945	833	12	336
369	747	704	1105	838	12	336
370	762	694	1101	830	12	348
371	995	679	1392	869	12	348
372	759	705	1104	838	12	360
373	1277	515	1681	702	12	360
374	758	712	1107	838	12	370
375	1102	269	1504	474	12	370
376	749	715	1107	844	12	383
377	545	245	800	594	12	383
378	732	690	1139	892	12	394
379	749	715	1102	853	12	404
380	1137	645	1560	840	12	404
381	741	730	1100	850	12	417
382	1112	404	1516	599	12	417
383	757	710	1110	849	12	429
384	716	101	1014	458	12	429
385	532	341	821	685	12	439
386	763	733	1105	842	12	439
387	712	675	1110	882	12	450
388	760	720	1113	854	12	463
389	1176	560	1607	793	12	463
390	759	723	1106	849	12	473
391	1129	314	1524	501	12	473
392	752	717	1110	853	12	484
393	721	106	1029	444	12	484
394	725	657	1121	872	12	502
395	762	715	1113	842	12	515
396	1192	601	1591	783	12	515
397	760	712	1112	844	12	525
398	1319	364	1742	560	12	525
399	764	712	1123	852	12	538
400	784	200	1150	500	12	538
401	775	722	1116	853	12	551
402	534	394	840	725	12	551
403	883	712	1300	891	12	561
404	754	705	1110	843	12	574
405	1251	469	1679	664	12	574
406	757	723	1115	847	12	587
407	1249	548	1664	732	12	587
408	764	724	1115	857	12	597
409	630	168	902	516	12	597
410	633	635	1018	879	12	610
411	1071	668	1482	876	12	622
412	776	749	1122	874	12	622
413	1214	455	1625	636	12	635
414	767	737	1118	860	12	635
415	764	738	1135	862	12	645
416	878	206	1284	485	12	645
417	769	739	1129	858	12	654
418	637	97	897	460	12	654
419	473	489	793	805	12	664
420	778	695	1123	852	12	664
421	786	704	1203	901	12	673
422	776	749	1124	869	12	687
423	1168	565	1573	742	12	687
424	760	748	1127	858	12	700
425	1012	256	1403	461	12	700
426	770	740	1118	859	12	710
427	646	97	927	451	12	710
428	558	639	942	887	12	724
429	808	739	1123	855	12	724
430	765	738	1109	852	12	737
431	1077	684	1490	884	12	737
432	767	725	1115	868	12	747
433	1271	505	1689	722	12	747
434	759	720	1116	852	12	756
435	1115	312	1524	494	12	756
436	763	714	1115	854	12	766
437	751	117	1078	421	12	766
438	754	734	1112	855	12	775
439	534	304	798	644	12	775
440	587	628	961	872	12	785
441	787	723	1116	858	12	785
442	753	723	1105	849	12	799
443	1082	650	1494	866	12	799
444	756	729	1110	843	12	813
445	1294	332	1697	534	12	813
446	752	712	1102	844	12	827
447	703	77	1003	396	12	827
448	757	714	1111	849	12	837
449	421	340	703	698	12	837
450	702	718	1115	908	12	851
451	751	727	1110	854	12	865
452	1207	578	1624	799	12	865
453	752	719	1105	853	12	878
454	1100	299	1497	485	12	878
455	746	714	1101	855	12	888
456	699	73	985	395	12	888
457	752	715	1098	858	12	899
458	439	516	776	828	12	899
459	648	718	1043	907	12	911
460	748	745	1082	858	12	921
461	1000	659	1418	842	12	921
462	756	730	1101	854	12	932
463	1266	433	1685	635	12	932
464	763	729	1107	849	12	949
465	640	73	914	426	12	949
466	762	734	1104	847	12	960
467	471	561	825	848	12	960
468	907	703	1305	886	12	975
469	745	727	1104	860	12	985
470	1090	598	1488	787	12	985
471	741	719	1101	858	12	995
472	1133	337	1530	513	12	995
473	735	724	1096	853	12	1009
474	664	86	961	427	12	1009
475	585	591	936	853	12	1019
476	752	718	1099	862	12	1019
477	763	688	1113	819	12	84
478	1187	578	1579	743	12	84
479	774	700	1118	814	12	98
480	907	157	1280	409	12	98
481	768	690	1116	822	12	109
482	556	146	790	508	12	109
483	641	649	1021	854	12	119
484	752	704	1110	830	12	135
485	1174	571	1582	768	12	135
486	754	697	1107	817	12	145
487	1084	306	1470	485	12	145
488	749	689	1115	827	12	155
489	718	52	1006	376	12	155
490	664	610	1056	817	12	171
491	756	718	1095	819	12	181
492	1058	636	1458	817	12	181
493	751	718	1102	822	12	192
494	1182	433	1575	565	12	192
495	748	713	1105	820	12	203
496	793	118	1176	407	12	203
497	747	692	1098	818	12	218
498	396	436	704	758	12	218
499	596	643	968	862	12	229
500	762	697	1095	815	12	229
501	754	703	1080	824	12	239
502	1047	645	1452	827	12	239
503	751	704	1100	822	12	255
504	1055	237	1442	431	12	255
505	742	698	1098	817	12	267
506	643	108	914	436	12	267
507	581	623	956	862	12	282
508	774	704	1098	819	12	282
509	746	707	1061	835	12	292
510	997	653	1400	853	12	292
511	741	715	1099	827	12	303
513	1267	486	1687	687	12	303
515	747	715	1105	834	12	314
516	1071	239	1450	424	12	314
517	580	172	832	526	12	327
518	752	727	1101	840	12	327
519	521	466	863	784	12	337
520	743	717	1104	848	12	337
521	936	684	1333	876	12	349
522	753	719	1107	838	12	361
523	1282	488	1689	667	12	361
524	751	718	1110	840	12	371
525	1050	250	1442	453	12	371
526	757	727	1104	844	12	382
527	567	197	798	555	12	382
528	785	714	1195	898	12	395
529	747	728	1100	849	12	405
530	1162	636	1570	822	12	405
531	746	727	1096	860	12	416
532	1130	425	1536	618	12	416
533	756	730	1111	848	12	428
534	758	140	1077	469	12	428
535	754	735	1109	844	12	438
536	542	302	820	663	12	438
537	793	698	1211	882	12	451
538	753	727	1109	842	12	462
540	1183	596	1585	798	12	462
541	753	725	1113	848	12	472
542	1145	349	1542	520	12	472
543	753	729	1109	852	12	485
544	692	91	958	443	12	485
545	686	620	1061	863	12	501
546	760	734	1112	842	12	514
547	1157	620	1564	798	12	514
548	763	735	1115	845	12	524
549	1345	412	1747	594	12	524
550	740	167	1055	485	12	537
551	768	732	1117	850	12	537
552	537	490	862	789	12	550
553	770	743	1115	848	12	550
554	797	692	1198	888	12	560
555	762	727	1115	843	12	573
556	1273	509	1674	674	12	573
557	757	738	1113	844	12	586
558	1237	581	1641	770	12	586
559	770	739	1117	848	12	596
560	649	117	906	476	12	596
562	607	599	975	859	12	609
563	765	735	1116	855	12	609
564	770	739	1117	862	12	623
565	1106	680	1501	859	12	623
566	770	755	1126	862	12	636
567	1204	459	1603	615	12	636
568	769	728	1122	855	12	650
569	734	101	1032	429	12	650
570	776	727	1128	852	12	660
571	492	337	763	678	12	660
572	845	710	1254	892	12	674
573	768	747	1124	866	12	688
574	1174	531	1570	698	12	688
575	769	748	1120	862	12	701
577	952	229	1348	443	12	701
578	767	748	1120	857	12	711
579	635	131	896	491	12	711
580	589	652	964	887	12	725
582	867	745	1116	853	12	725
583	770	745	1116	859	12	738
584	1116	662	1521	873	12	738
585	764	745	1116	857	12	752
586	1234	414	1635	596	12	752
587	763	730	1116	852	12	762
589	929	186	1312	429	12	762
590	763	730	1112	859	12	776
591	508	331	795	679	12	776
593	707	694	1112	896	12	789
594	759	727	1068	863	12	798
595	1063	693	1455	868	12	798
596	757	733	1109	853	12	807
599	1332	506	1718	723	12	807
600	752	719	1106	845	12	817
601	1218	264	1618	440	12	817
602	756	715	1107	842	12	826
603	745	85	1067	390	12	826
604	759	723	1110	850	12	836
607	431	305	686	660	12	836
608	512	648	900	887	12	845
609	858	724	1106	842	12	845
610	865	708	1283	899	12	855
611	754	729	1109	845	12	863
612	1177	619	1581	838	12	863
613	749	737	1105	849	12	873
614	1217	435	1619	628	12	873
615	751	733	1104	844	12	882
616	979	195	1361	409	12	882
617	746	719	1105	850	12	895
618	478	314	762	669	12	895
619	499	662	886	896	12	905
620	843	740	1098	849	12	905
621	800	685	1215	879	12	916
622	748	739	1104	852	12	929
623	1245	526	1658	728	12	929
624	753	738	1109	852	12	939
626	1156	229	1580	426	12	939
627	748	715	1104	849	12	948
629	688	48	979	385	12	948
630	749	729	1101	848	12	958
632	433	478	767	780	12	958
633	690	723	1088	909	12	967
634	952	694	1354	868	12	977
635	758	728	962	842	12	977
636	754	730	1096	853	12	991
637	1151	459	1547	631	12	991
638	737	725	1098	852	12	1001
639	1000	182	1388	394	12	1001
640	575	260	839	604	12	1013
641	741	733	1100	853	12	1013
642	764	690	1118	815	12	85
643	1190	544	1586	727	12	85
644	760	687	1120	820	12	93
645	1088	309	1479	511	12	93
646	764	680	1121	819	12	103
647	707	28	1016	384	12	103
648	768	680	1120	820	12	111
649	527	259	782	610	12	111
650	665	639	1061	848	12	121
651	762	703	1001	822	12	128
652	1001	650	1407	822	12	128
653	751	705	1104	817	12	138
654	1205	544	1602	725	12	138
655	758	679	1105	825	12	146
656	1021	227	1403	433	12	146
657	748	703	1106	820	12	156
658	676	41	944	384	12	156
659	753	694	1106	823	12	164
660	531	247	793	591	12	164
661	806	672	1212	850	12	174
662	745	704	1101	819	12	189
663	1227	496	1626	680	12	189
664	753	703	1101	827	12	199
665	920	176	1286	410	12	199
666	743	697	1099	828	12	209
667	539	98	767	458	12	209
668	398	459	715	785	12	217
669	752	709	1096	823	12	217
670	552	635	933	857	12	227
671	880	702	1095	817	12	227
672	919	665	1326	854	12	235
673	749	690	1102	824	12	245
674	1222	506	1614	694	12	245
675	743	698	1095	824	12	254
676	1087	246	1476	443	12	254
677	738	695	1099	828	12	263
678	731	36	1068	357	12	263
679	429	445	737	770	12	273
680	757	724	1094	828	12	273
681	608	641	996	859	12	284
682	914	714	1093	820	12	284
683	747	717	1095	832	12	294
684	1082	646	1499	834	12	294
685	743	717	1098	828	12	304
686	1273	471	1687	658	12	304
687	746	709	1102	829	12	310
688	1183	309	1582	503	12	310
689	748	703	1102	833	12	320
690	775	83	1134	389	12	320
691	555	217	809	570	12	328
692	749	713	1095	838	12	328
693	600	561	983	842	12	338
694	917	712	1096	824	12	338
695	692	652	1082	855	12	345
697	1156	609	1548	802	12	355
698	751	720	1105	830	12	355
699	752	713	1101	834	12	362
700	1284	451	1692	649	12	362
701	747	703	1106	837	12	372
702	992	216	1382	439	12	372
703	749	683	1106	839	12	379
704	598	86	845	463	12	379
706	576	576	949	844	12	389
707	923	723	1101	840	12	389
708	896	704	1304	901	12	396
709	1174	629	1585	823	12	406
710	741	718	1100	849	12	406
711	743	729	1102	852	12	413
712	1183	520	1592	690	12	413
713	752	714	1107	854	12	423
714	944	282	1320	525	12	423
715	751	709	1107	848	12	430
716	676	72	953	425	12	430
717	753	729	1110	847	12	440
718	515	399	812	717	12	440
719	599	619	980	866	12	447
720	896	723	1104	840	12	447
721	760	723	1055	853	12	457
722	1056	664	1468	857	12	457
723	756	714	1111	850	12	464
724	1204	569	1615	778	12	464
725	749	720	1110	852	12	474
726	1105	295	1491	481	12	474
727	758	718	1107	849	12	481
728	834	178	1233	463	12	481
729	752	719	1110	850	12	491
730	618	250	873	590	12	491
731	760	744	1106	848	12	497
732	585	503	920	798	12	497
733	891	693	1295	887	12	507
734	764	729	1117	848	12	516
735	1220	593	1618	784	12	516
736	762	734	1117	852	12	526
737	1301	346	1709	533	12	526
738	758	733	1117	853	12	533
739	1007	262	1382	463	12	533
740	758	715	1116	853	12	543
741	581	143	809	500	12	543
742	555	559	906	838	12	552
743	912	734	1117	843	12	552
744	831	712	1253	894	12	562
745	763	729	1112	850	12	569
747	1179	614	1582	810	12	569
748	757	733	1113	852	12	579
749	1193	362	1598	528	12	579
750	763	722	1115	859	12	588
751	914	182	1322	427	12	588
752	769	718	1121	858	12	598
753	616	216	887	560	12	598
754	543	470	879	785	12	605
757	770	740	1117	859	12	605
758	802	737	1217	904	12	615
759	765	740	1123	866	12	624
760	1122	663	1534	863	12	624
761	765	740	1115	857	12	632
763	1256	540	1662	730	12	632
764	769	728	1121	855	12	642
765	1045	316	1432	516	12	642
766	767	718	1124	855	12	651
767	699	96	994	430	12	651
768	760	735	1123	852	12	661
769	476	387	770	712	12	661
771	642	669	1038	879	12	670
772	958	745	1118	849	12	670
773	773	738	1060	866	12	679
774	1050	687	1455	877	12	679
775	769	743	1123	864	12	689
776	1167	510	1565	678	12	689
777	763	720	1124	855	12	697
778	1096	335	1490	509	12	697
779	770	730	1117	852	12	707
780	763	101	1065	410	12	707
781	517	360	795	680	12	716
782	768	747	1120	859	12	716
783	602	662	1000	886	12	726
784	925	743	1115	847	12	726
785	956	717	1372	902	12	734
786	764	723	1113	857	12	744
788	1255	549	1668	782	12	744
789	759	742	1116	859	12	753
790	1212	387	1610	551	12	753
791	758	713	1115	855	12	763
792	870	175	1266	425	12	763
793	759	723	1113	854	12	772
794	588	183	824	531	12	772
795	531	541	876	825	12	782
796	889	740	1111	853	12	782
797	749	734	1141	899	12	790
798	760	735	1109	857	12	800
799	1122	646	1524	845	12	800
800	756	723	1109	845	12	809
802	1339	450	1734	649	12	809
803	765	699	1115	814	12	86
804	1199	523	1586	700	12	86
805	769	700	1118	819	12	94
806	995	213	1365	430	12	94
807	773	692	1123	813	12	104
808	603	18	869	389	12	104
809	514	394	809	700	12	112
810	779	705	1115	814	12	112
811	813	668	1217	845	12	122
812	946	663	1354	833	12	129
813	753	699	1105	817	12	139
815	1217	504	1608	697	12	139
816	753	704	1110	823	12	147
817	1051	281	1437	458	12	147
818	756	698	1106	824	12	157
819	643	60	903	402	12	157
820	760	705	1107	820	12	165
821	503	411	825	724	12	165
822	558	516	924	783	12	175
824	754	717	1105	818	12	175
825	746	703	1105	822	12	184
826	1144	620	1540	789	12	184
827	747	703	1104	823	12	194
828	1238	530	1631	704	12	194
829	746	710	1098	825	12	204
830	679	56	968	389	12	204
831	746	700	1095	822	12	213
832	427	294	688	640	12	213
833	459	599	842	853	12	222
834	770	715	1093	814	12	222
835	668	669	1065	860	12	230
836	749	705	1099	829	12	240
837	1120	620	1516	812	12	240
838	748	697	1102	819	12	249
839	1223	476	1615	649	12	249
840	745	697	1096	824	12	258
841	879	150	1282	386	12	258
842	746	685	1096	815	12	268
843	592	186	869	534	12	268
844	748	698	1098	825	12	276
845	445	372	747	712	12	276
846	729	668	1116	864	12	286
847	748	698	1099	828	12	297
849	1203	593	1601	789	12	297
850	745	710	1100	829	12	307
851	1250	392	1656	573	12	307
852	749	715	1104	829	12	317
853	896	148	1287	387	12	317
854	749	703	1096	835	12	324
855	649	76	925	421	12	324
856	508	450	829	759	12	334
857	756	729	1099	832	12	334
858	845	697	1249	876	12	342
859	746	720	1077	825	12	352
860	1077	674	1466	837	12	352
861	759	719	1109	840	12	364
862	1273	417	1672	574	12	364
863	749	718	1109	837	12	376
864	734	85	1060	409	12	376
865	749	718	1106	847	12	386
866	511	400	815	730	12	386
867	753	730	985	847	12	398
868	990	718	1404	888	12	398
869	749	728	1101	852	12	410
870	1204	585	1603	772	12	410
871	751	723	1101	847	12	420
872	1046	326	1426	536	12	420
873	756	714	1109	852	12	432
874	629	40	884	411	12	432
875	533	545	872	842	12	444
876	883	722	1109	840	12	444
877	907	692	1322	881	12	454
878	758	713	1109	849	12	466
879	1214	549	1620	729	12	466
880	763	717	1105	853	12	478
881	963	245	1352	459	12	478
882	758	719	1111	845	12	488
883	653	176	898	525	12	488
884	577	385	872	708	12	495
885	757	730	1109	847	12	495
886	806	679	1206	877	12	505
887	763	717	1112	839	12	512
888	1105	652	1504	825	12	512
889	764	722	1126	840	12	522
891	1349	459	1749	657	12	522
892	758	713	1116	844	12	531
893	1091	265	1496	424	12	531
894	754	719	1111	849	12	541
895	652	116	917	468	12	541
896	759	737	1122	852	12	548
897	534	357	825	688	12	548
898	661	672	1072	887	12	558
899	762	739	1113	849	12	567
900	1105	679	1508	862	12	567
901	757	733	1113	853	12	577
902	1232	402	1640	573	12	577
903	764	727	1115	854	12	584
904	1000	236	1397	434	12	584
905	759	719	1117	857	12	594
906	688	66	978	419	12	594
907	543	411	872	730	12	603
908	763	744	1117	860	12	603
909	738	718	1133	896	12	613
910	769	739	1012	864	12	620
911	1017	732	1424	903	12	620
912	763	734	1120	860	12	630
913	1256	601	1658	779	12	630
914	767	737	1122	862	12	639
915	1133	386	1536	558	12	639
916	764	734	1121	860	12	648
917	785	152	1143	449	12	648
918	769	738	1129	859	12	658
919	550	257	785	609	12	658
920	521	589	892	853	12	667
921	895	738	1123	845	12	667
922	981	714	1398	904	12	677
923	765	733	1126	873	12	685
924	1162	613	1569	794	12	685
925	773	728	1120	864	12	695
926	1120	389	1523	546	12	695
927	765	725	1123	858	12	704
928	854	173	1244	429	12	704
929	764	744	1118	862	12	714
930	563	292	828	630	12	714
931	522	565	878	864	12	722
932	884	738	1121	857	12	722
933	865	738	1283	917	12	732
934	769	730	1133	864	12	741
935	1204	614	1624	832	12	741
936	763	735	1118	862	12	750
937	1266	471	1672	650	12	750
938	762	742	1118	859	12	760
939	1019	242	1396	440	12	760
940	763	734	1116	857	12	769
941	655	103	916	449	12	769
942	501	444	823	762	12	779
943	768	749	1115	857	12	779
944	675	693	1076	891	12	788
945	760	724	1005	845	12	797
946	1011	718	1414	877	12	797
947	753	724	1105	854	12	806
948	1304	525	1696	750	12	806
949	754	719	1116	850	12	816
950	1238	300	1653	475	12	816
951	749	725	1109	844	12	825
952	776	107	1165	382	12	825
953	754	720	1106	849	12	835
954	434	266	697	630	12	835
955	475	606	867	874	12	844
956	864	730	1105	842	12	844
957	764	683	1120	824	12	87
958	1189	504	1585	659	12	87
959	769	687	1123	817	12	95
960	942	183	1322	411	12	95
961	768	689	1121	815	12	105
962	676	22	957	377	12	105
963	510	445	831	749	12	113
964	835	717	1121	813	12	113
965	694	665	1101	853	12	123
966	756	709	1033	822	12	130
967	1040	658	1448	820	12	130
968	751	697	1109	818	12	140
969	1211	468	1593	614	12	140
970	756	693	1107	824	12	148
971	992	206	1374	416	12	148
972	758	693	1109	822	12	158
973	613	81	864	436	12	158
974	521	449	847	735	12	166
975	747	719	1111	832	12	166
976	907	689	1317	858	12	176
978	1170	605	1581	784	12	185
979	749	697	1102	823	12	185
980	754	713	1100	824	12	195
981	989	246	1377	439	12	195
982	749	698	1100	824	12	205
983	712	77	1032	391	12	205
984	426	604	798	845	12	223
985	759	702	1093	822	12	223
986	720	693	1110	858	12	231
987	747	719	1100	823	12	241
989	1199	574	1584	753	12	241
990	749	704	1094	819	12	250
991	1195	396	1587	543	12	250
992	745	709	1096	819	12	259
993	875	152	1292	389	12	259
994	745	705	1096	820	12	269
995	569	239	843	571	12	269
996	427	518	774	820	12	277
997	767	707	1095	824	12	277
998	797	682	1211	869	12	287
999	745	707	1098	824	12	298
1000	1221	575	1628	787	12	298
1001	741	713	1111	832	12	308
1002	1225	385	1635	550	12	308
1003	746	692	1104	828	12	318
1004	846	127	1240	386	12	318
1005	745	700	1096	834	12	330
1006	499	305	787	639	12	330
1008	873	708	1281	888	12	343
1010	743	700	1100	843	12	353
1011	1106	653	1501	827	12	353
1012	757	715	1106	844	12	365
1013	1242	387	1643	553	12	365
1014	757	724	1106	840	12	377
1015	663	55	916	399	12	377
1016	514	451	835	754	12	387
1017	763	749	1107	847	12	387
1018	938	700	1354	903	12	399
1019	752	730	1100	850	12	411
1020	1194	580	1598	747	12	411
1021	749	734	1106	850	12	421
1022	1008	316	1387	521	12	421
1023	758	725	1107	845	12	433
1024	619	65	851	430	12	433
1025	565	603	941	863	12	446
1026	885	722	1105	840	12	446
1027	962	694	1377	871	12	456
1028	751	729	1112	848	12	468
1029	1198	488	1606	648	12	468
1030	758	727	1110	849	12	479
1031	892	217	1284	455	12	479
1032	757	737	1106	854	12	489
1033	638	215	887	554	12	489
1034	657	596	1013	845	12	499
1035	759	734	1002	854	12	509
1036	1014	695	1414	860	12	509
1037	764	718	1122	849	12	518
1038	1283	559	1680	752	12	518
1039	768	722	1118	848	12	528
1040	1140	256	1549	417	12	528
1041	763	715	1118	847	12	535
1042	837	231	1234	490	12	535
1043	572	183	803	535	12	545
1044	762	739	1111	849	12	545
1045	575	601	941	847	12	554
1046	931	738	1115	845	12	554
1047	764	730	990	845	12	564
1048	989	709	1393	878	12	564
1049	751	722	1118	849	12	571
1050	1200	620	1600	808	12	571
1051	767	709	1115	848	12	581
1052	1141	324	1546	489	12	581
1053	769	734	1118	852	12	590
1054	789	117	1165	407	12	590
1055	594	312	876	644	12	600
1056	763	750	1118	859	12	600
1057	565	545	916	822	12	607
1058	924	735	1121	855	12	607
1059	896	723	1297	909	12	617
1060	767	737	1121	859	12	626
1062	1185	640	1578	839	12	626
1063	771	733	1118	858	12	634
1064	1239	489	1641	687	12	634
1065	768	733	1120	855	12	644
1066	949	271	1339	489	12	644
1067	778	725	1124	857	12	653
1068	655	90	916	430	12	653
1069	465	459	778	760	12	663
1070	785	747	1127	853	12	663
1071	741	708	1152	897	12	672
1072	776	740	1116	864	12	681
1073	1111	680	1510	855	12	681
1074	768	724	1127	860	12	691
1075	1159	469	1557	638	12	691
1076	770	725	1120	873	12	699
1077	1038	286	1429	486	12	699
1078	767	733	1118	866	12	709
1079	691	97	970	430	12	709
1080	780	730	1116	866	12	718
1081	497	445	803	764	12	718
1082	692	710	1088	907	12	728
1083	1045	709	1446	906	12	736
1084	770	729	1049	871	12	736
1085	767	743	1112	869	12	746
1086	1281	519	1681	748	12	746
1087	767	728	1115	853	12	755
1088	1154	344	1547	516	12	755
1089	770	710	1120	852	12	765
1090	781	140	1143	421	12	765
1091	554	255	795	610	12	774
1092	762	744	1113	858	12	774
1093	567	614	933	863	12	784
1094	929	752	1110	848	12	784
1095	808	713	1216	896	12	792
1096	754	723	1110	859	12	802
1097	1200	635	1593	818	12	802
1098	763	728	1111	842	12	811
1100	1322	400	1729	591	12	811
1101	752	723	1116	843	12	821
1102	1060	207	1465	377	12	821
1103	749	727	1107	849	12	830
1104	571	82	837	448	12	830
1105	759	733	1106	855	12	840
1106	409	501	748	805	12	840
1107	621	704	1040	892	12	849
1108	936	745	1111	848	12	849
1109	752	738	1005	854	12	858
1110	1014	712	1410	889	12	858
1111	753	747	1104	855	12	868
1112	1242	560	1641	744	12	868
1113	767	685	1117	825	12	88
1114	1174	479	1581	633	12	88
1115	763	702	1124	815	12	96
1116	1028	249	1403	458	12	96
1117	648	16	917	375	12	106
1118	773	688	1124	814	12	106
1119	512	329	792	652	12	114
1120	765	695	1122	817	12	114
1121	857	652	1262	847	12	124
1122	774	677	1073	824	12	131
1123	1084	643	1476	817	12	131
1124	753	693	1113	823	12	141
1125	1184	431	1586	616	12	141
1126	752	694	1109	820	12	149
1127	1051	275	1436	470	12	149
1128	754	708	1112	824	12	159
1129	572	167	824	521	12	159
1130	527	473	883	765	12	167
1131	878	709	1105	819	12	167
1133	999	683	1396	852	12	177
1135	752	697	1006	820	12	177
1136	747	710	1105	825	12	186
1137	1216	568	1613	748	12	186
1138	746	707	1102	824	12	196
1139	1080	321	1472	495	12	196
1140	747	699	1101	823	12	206
1141	745	91	1101	390	12	206
1142	412	347	686	690	12	214
1143	738	698	1098	825	12	214
1144	437	609	820	863	12	224
1145	810	708	1096	818	12	224
1146	773	680	1172	863	12	232
1147	746	707	1098	825	12	242
1148	1214	564	1600	755	12	242
1149	743	708	1099	818	12	251
1150	1143	339	1535	486	12	251
1151	743	697	1098	820	12	260
1152	823	100	1211	374	12	260
1153	751	677	1096	837	12	270
1154	497	312	782	645	12	270
1155	487	598	880	850	12	278
1156	852	707	1094	820	12	278
1157	763	678	1161	867	12	288
1158	752	680	1102	828	12	300
1160	1276	546	1667	745	12	300
1161	749	683	1105	824	12	311
1162	1149	299	1552	459	12	311
1163	747	714	1105	835	12	321
1164	745	86	1071	386	12	321
1165	541	255	793	598	12	329
1166	752	713	1098	838	12	329
1167	641	631	1036	850	12	339
1168	731	674	1120	868	12	346
1169	743	710	1104	843	12	356
1170	1266	534	1664	743	12	356
1171	743	707	1104	847	12	363
1172	1283	441	1681	613	12	363
1173	745	708	1107	839	12	373
1174	909	207	1322	441	12	373
1175	626	68	891	417	12	380
1176	748	733	1107	838	12	380
1177	530	498	872	802	12	390
1178	872	743	1110	837	12	390
1179	820	709	1254	898	12	397
1181	746	737	1110	840	12	407
1182	1189	644	1603	800	12	407
1183	738	717	1106	850	12	414
1184	1160	486	1560	648	12	414
1185	746	744	1106	848	12	424
1186	874	270	1264	511	12	424
1187	758	723	1109	848	12	431
1188	648	71	914	410	12	431
1189	512	445	825	754	12	441
1190	745	732	1106	847	12	441
1191	646	667	1023	873	12	448
1192	754	740	1094	849	12	458
1193	1093	684	1503	845	12	458
1194	759	727	1109	845	12	465
1195	1214	560	1625	750	12	465
1196	752	728	1115	854	12	475
1197	1071	291	1460	460	12	475
1198	767	729	1116	844	12	482
1199	780	163	1141	455	12	482
1200	752	732	1106	850	12	492
1201	585	331	869	660	12	492
1202	622	578	978	839	12	498
1204	923	729	1113	849	12	498
1205	973	688	1372	887	12	508
1206	768	723	1123	857	12	517
1207	1249	578	1650	765	12	517
1208	757	739	1120	853	12	527
1210	1267	311	1681	484	12	527
1211	760	739	1120	852	12	534
1212	906	264	1315	486	12	534
1213	769	729	1122	849	12	544
1214	554	276	818	629	12	544
1215	548	529	881	815	12	553
1216	883	734	1116	849	12	553
1217	929	713	1356	882	12	563
1218	1146	657	1564	835	12	570
1219	760	745	1121	852	12	570
1220	764	725	1117	860	12	580
1221	1168	341	1576	511	12	580
1222	762	735	1121	854	12	589
1223	843	157	1253	424	12	589
1224	769	733	1122	858	12	599
1225	607	259	884	616	12	599
1226	547	511	895	798	12	606
1227	778	763	1121	863	12	606
1228	837	727	1267	909	12	616
1229	1155	658	1562	848	12	625
1230	769	734	1128	866	12	625
1231	765	733	1127	862	12	633
1232	1242	531	1654	698	12	633
1234	769	749	1126	858	12	643
1235	992	297	1391	504	12	643
1236	674	97	953	435	12	652
1237	771	725	1121	854	12	652
1238	473	421	767	743	12	662
1239	770	730	1126	867	12	662
1240	699	677	1106	896	12	671
1242	1084	684	1483	871	12	680
1243	763	737	1083	863	12	680
1244	768	749	1122	872	12	690
1245	1156	486	1558	658	12	690
1246	768	724	1123	868	12	698
1247	1074	305	1464	495	12	698
1248	767	724	1121	864	12	708
1249	727	108	1029	420	12	708
1250	495	401	796	719	12	717
1251	773	748	1118	864	12	717
1252	650	694	1050	903	12	727
1253	764	735	1005	853	12	735
1254	1000	728	1411	906	12	735
1255	760	737	1111	862	12	745
1257	1288	546	1680	765	12	745
1258	759	730	1118	859	12	754
1259	1184	380	1585	535	12	754
1260	762	742	1123	862	12	764
1261	821	160	1222	426	12	764
1262	760	737	1113	860	12	773
1263	565	239	809	565	12	773
1264	543	580	902	842	12	783
1265	902	748	1111	850	12	783
1266	784	703	1181	898	12	791
1267	763	710	1117	855	12	801
1268	1167	614	1558	828	12	801
1269	767	710	1110	860	12	810
1270	1332	404	1738	613	12	810
1271	775	689	1121	823	12	89
1272	1170	441	1565	608	12	89
1273	769	673	1120	817	12	97
1274	1062	292	1437	478	12	97
1275	775	678	1124	819	12	107
1276	591	43	832	420	12	107
1277	537	498	861	783	12	115
1278	878	699	1113	815	12	115
1279	741	675	1128	860	12	125
1280	760	690	1106	829	12	132
1281	1120	620	1509	795	12	132
1282	762	697	1106	819	12	142
1283	1140	365	1527	534	12	142
1284	763	699	1104	818	12	150
1285	951	182	1328	394	12	150
1286	594	125	843	476	12	160
1287	754	695	1104	824	12	160
1288	764	702	1107	827	12	168
1289	509	372	812	684	12	168
1290	869	650	1270	871	12	178
1291	757	694	1102	823	12	187
1292	1238	521	1625	737	12	187
1293	745	693	1111	820	12	197
1294	1027	261	1419	458	12	197
1295	741	688	1107	822	12	207
1296	630	60	914	404	12	207
1297	740	697	1102	819	12	215
1298	487	198	710	560	12	215
1299	497	629	867	857	12	225
1300	858	717	1098	813	12	225
1301	868	694	1284	862	12	233
1302	747	700	1110	837	12	243
1303	1140	608	1538	784	12	243
1304	737	703	1095	824	12	252
1305	1113	295	1503	473	12	252
1306	740	700	1096	823	12	261
1307	776	71	1154	362	12	261
1308	533	272	803	599	12	271
1309	740	692	1096	825	12	271
1310	476	601	848	844	12	279
1311	834	704	1098	818	12	279
1312	843	682	1254	855	12	289
1315	747	697	1109	824	12	299
1313	1249	581	1648	760	12	299
1316	752	704	1104	828	12	309
1317	1209	335	1613	519	12	309
1318	752	715	1106	833	12	319
1319	806	115	1171	377	12	319
1320	498	374	786	695	12	331
1321	752	719	1094	830	12	331
1323	909	682	1309	882	12	344
1325	1129	638	1527	815	12	354
1326	754	723	1104	833	12	354
1327	749	720	1113	838	12	366
1328	1220	355	1619	526	12	366
1329	754	713	1102	844	12	378
1330	713	66	985	412	12	378
1331	559	545	900	827	12	388
1332	911	737	1101	838	12	388
1333	756	714	1024	847	12	400
1335	1043	719	1447	879	12	400
1336	753	720	1098	850	12	412
1337	1193	536	1597	742	12	412
1338	762	717	1112	852	12	422
1339	981	309	1365	524	12	422
1340	759	725	1107	843	12	434
1341	620	120	842	479	12	434
1342	558	571	902	845	12	445
1343	906	722	1109	840	12	445
1344	756	703	1014	858	12	455
1345	1018	682	1425	863	12	455
1346	756	722	1107	847	12	467
1347	1216	505	1613	670	12	467
1348	758	714	1110	848	12	480
1349	840	182	1216	463	12	480
1350	613	284	865	608	12	490
1351	754	723	1107	854	12	490
1352	607	526	942	812	12	500
1353	938	734	1104	845	12	500
1355	760	734	1111	845	12	513
1356	1141	649	1536	823	12	513
1357	765	715	1117	847	12	523
1358	1355	434	1757	618	12	523
1359	763	718	1113	853	12	536
1360	793	193	1143	496	12	536
1361	533	444	845	753	12	549
1362	853	733	1120	852	12	549
1363	757	705	1151	889	12	559
1364	753	729	1120	847	12	572
1365	1227	603	1620	785	12	572
1367	760	744	1115	849	12	585
1368	1264	526	1662	719	12	585
1369	768	717	1116	860	12	595
1370	672	88	931	444	12	595
1371	580	569	942	848	12	608
1372	939	742	1110	858	12	608
1373	774	717	1056	868	12	621
1374	1061	697	1446	891	12	621
1375	756	738	1118	859	12	631
1376	1258	564	1665	762	12	631
1377	742	663	1121	855	12	893
1378	539	193	798	589	12	893
1379	735	648	1125	864	12	880
1381	1028	222	1459	459	12	880
1382	1237	452	1647	690	12	871
1383	743	644	1130	866	12	871
1384	739	676	1114	857	12	861
1385	1117	617	1542	864	12	861
1386	708	725	1112	944	12	1120
1387	661	547	1035	854	12	1110
1388	737	687	1104	864	12	1103
1389	697	98	1019	500	12	1103
1390	1052	370	1483	639	12	1093
1391	729	664	1099	871	12	1093
1392	993	623	1426	852	12	1084
1393	731	700	1085	865	12	1084
1394	671	693	1091	931	12	1074
1395	745	697	1111	868	12	1066
1396	491	529	854	842	12	1066
1397	723	699	1124	869	12	1056
1398	719	98	1075	449	12	1056
1399	1096	301	1533	541	12	1049
1400	746	700	1120	862	12	1049
1401	746	691	1119	868	12	1039
1402	1196	562	1637	816	12	1039
1403	936	682	1379	892	12	1031
1404	731	681	970	855	12	1031
1405	613	633	1027	900	12	1021
1406	859	697	1106	853	12	1021
1407	732	698	1116	864	12	1014
1408	538	309	864	671	12	1014
1409	731	695	1113	862	12	1004
1410	841	118	1257	418	12	1004
1411	736	694	1123	868	12	997
1412	1091	257	1518	474	12	997
1413	735	708	1122	867	12	987
1414	1116	548	1532	760	12	987
1415	1019	641	1432	862	12	980
1416	732	726	1043	857	12	980
1417	772	687	1190	933	12	970
1418	483	606	872	869	12	961
1419	769	702	1117	857	12	961
1420	733	720	1134	872	12	952
1421	553	201	832	597	12	952
1422	745	712	1125	870	12	942
1423	1009	148	1446	380	12	942
1424	750	712	1120	864	12	933
1425	1260	379	1706	617	12	933
1426	743	695	1112	857	12	923
1427	1093	607	1524	838	12	923
1428	874	671	1300	882	12	918
1429	741	702	936	863	12	918
1430	565	668	988	923	12	908
1431	784	700	1121	857	12	908
1432	743	715	1115	869	12	900
1433	431	550	791	849	12	900
1434	717	695	1134	860	12	890
1435	583	43	900	441	12	890
1436	736	699	1125	859	12	881
1437	994	208	1427	451	12	881
1438	1242	436	1631	650	12	872
1439	751	718	1118	842	12	872
1440	745	693	1111	854	12	862
1441	1151	606	1562	863	12	862
1442	820	698	1242	914	12	854
1443	692	727	1114	950	12	1122
1444	696	653	1093	918	12	1112
1445	730	730	1113	860	12	1105
1446	667	209	958	573	12	1105
1447	737	710	1112	865	12	1095
1448	1023	320	1430	556	12	1095
1449	733	685	1102	855	12	1086
1450	1056	601	1472	803	12	1086
1451	735	698	1150	930	12	1076
1452	523	626	919	882	12	1068
1453	772	673	1111	847	12	1068
1454	766	706	1117	855	12	1058
1455	626	71	930	445	12	1058
1456	746	692	1111	857	12	1051
1457	1013	255	1439	496	12	1051
1458	752	689	1117	857	12	1041
1459	1240	508	1656	763	12	1041
1460	1026	640	1459	875	12	1033
1461	747	700	1035	857	12	1033
1462	666	667	1089	917	12	1023
1463	536	441	881	776	12	1016
1464	745	723	1109	859	12	1016
1465	737	685	1108	864	12	1006
1466	756	92	1138	410	12	1006
1467	1057	205	1465	422	12	999
1468	731	699	1106	854	12	999
1469	741	724	1111	856	12	989
1470	1130	480	1545	689	12	989
1471	1039	619	1452	840	12	982
1472	742	708	1058	853	12	982
1473	821	683	1236	896	12	972
1474	539	628	950	890	12	963
1475	820	686	1110	844	12	963
1476	758	694	1129	859	12	954
1477	483	313	778	670	12	954
1478	739	710	1112	865	12	944
1479	875	96	1313	368	12	944
1480	751	713	1114	861	12	935
1481	1253	312	1677	565	12	935
1482	748	701	1117	860	12	925
1483	1165	547	1597	806	12	925
1484	946	631	1383	853	12	920
1485	742	691	978	858	12	920
1486	615	691	1024	909	12	910
1487	751	712	1111	853	12	898
1488	444	460	767	790	12	898
1489	743	711	1116	851	12	889
1490	635	49	922	405	12	889
1491	742	685	1117	853	12	879
1492	1071	246	1479	449	12	879
1493	1232	428	1648	687	12	870
1494	748	671	1114	849	12	870
1495	1084	611	1494	878	12	860
1496	744	704	1100	850	12	860
1497	727	687	1158	904	12	852
1498	438	566	826	854	12	842
1499	757	708	1111	846	12	842
1500	754	692	1105	849	12	833
1501	489	168	742	556	12	833
1502	717	748	1116	948	12	1125
1503	716	736	1107	945	12	1117
1504	735	723	1104	861	12	1108
1505	656	403	984	741	12	1108
1506	735	709	1101	859	12	1098
1507	894	198	1311	492	12	1098
1508	739	679	1103	857	12	1090
1509	1093	458	1495	689	12	1090
1510	937	659	1356	884	12	1082
1511	741	708	953	857	12	1082
1512	623	678	1032	915	12	1072
1513	736	721	1126	856	12	1062
1514	538	263	822	650	12	1062
1515	743	690	1113	855	12	1055
1516	777	123	1145	453	12	1055
1517	1215	395	1638	617	12	1045
1518	749	689	1117	858	12	1045
1519	753	718	1113	857	12	1038
1520	1175	587	1597	827	12	1038
1521	839	688	1254	906	12	1028
1522	581	615	984	872	12	1020
1523	736	700	1105	857	12	1010
1524	624	93	907	461	12	1010
1525	745	689	1101	857	12	1003
1526	884	127	1303	400	12	1003
1527	1136	346	1553	578	12	993
1528	749	713	1106	852	12	993
1529	1111	568	1512	780	12	986
1530	756	685	1106	853	12	986
1531	928	682	1339	877	12	976
1532	749	689	1156	904	12	969
1533	432	512	803	826	12	959
1534	754	709	1111	851	12	959
1535	749	709	1113	856	12	950
1536	599	91	893	474	12	950
1537	749	697	1118	863	12	940
1538	1111	202	1551	412	12	940
1539	1279	431	1690	664	12	931
1540	750	714	1116	851	12	931
1541	1044	618	1472	844	12	922
1542	747	727	1052	861	12	922
1543	668	675	1078	909	12	912
1544	447	610	828	873	12	902
1545	753	703	1108	856	12	902
1546	740	696	1104	849	12	892
1547	567	126	811	521	12	892
1548	740	694	1105	854	12	885
1549	810	126	1223	405	12	885
1550	749	683	1117	853	12	875
1551	1176	346	1590	569	12	875
1552	1248	517	1643	780	12	867
1553	748	694	1117	856	12	867
1554	947	672	1386	902	12	857
1555	749	717	980	856	12	857
1556	586	669	1011	902	12	848
1557	848	700	1111	845	12	848
1558	397	438	741	780	12	839
1559	758	684	1117	857	12	839
1560	748	716	1113	853	12	829
1561	598	56	896	420	12	829
1562	744	704	1119	849	12	820
1563	1104	390	1104	390	12	820
1564	1104	172	1539	392	12	820
1565	703	722	1116	951	12	1121
1566	817	716	1094	845	12	1121
1567	669	593	1067	892	12	1111
1568	722	702	1102	864	12	1104
1569	674	136	978	525	12	1104
1570	1043	343	1452	592	12	1094
1571	736	699	1106	864	12	1094
1572	1025	608	1447	826	12	1085
1573	738	714	1097	856	12	1085
1574	703	705	1124	929	12	1075
1575	513	586	885	863	12	1067
1576	760	668	1104	845	12	1067
1577	744	690	1109	849	12	1057
1578	678	75	986	438	12	1057
1579	737	679	1115	864	12	1050
1580	1058	269	1485	512	12	1050
1581	1223	531	1643	789	12	1040
1582	748	701	1112	862	12	1040
1583	984	660	1415	883	12	1032
1584	738	713	1014	852	12	1032
1585	637	649	1046	897	12	1022
1586	745	717	1104	863	12	1015
1587	539	353	860	716	12	1015
1588	741	712	1105	858	12	1005
1589	789	98	1194	407	12	1005
1590	1070	225	1492	458	12	998
1591	731	703	1110	859	12	998
1592	743	698	1111	858	12	988
1593	1125	513	1533	732	12	988
1594	1033	618	1456	840	12	981
1595	743	720	1057	856	12	981
1596	802	687	1214	910	12	971
1597	506	612	911	883	12	962
1598	784	706	1112	845	12	962
1599	745	699	1119	866	12	953
1600	526	267	806	624	12	953
1601	748	713	1116	854	12	943
1602	950	115	1383	374	12	943
1603	758	710	1113	862	12	934
1604	1262	342	1698	593	12	934
1605	740	704	1115	861	12	924
1606	1129	572	1560	826	12	924
1607	915	640	1348	865	12	919
1608	595	676	1011	920	12	909
1609	751	694	1110	852	12	909
1610	737	694	1119	854	12	901
1611	443	561	809	873	12	901
1612	739	701	1111	860	12	891
1613	581	72	848	466	12	891
1614	743	702	1111	849	12	884
1615	850	138	1277	418	12	884
1616	1178	383	1625	613	12	874
1617	740	696	1126	868	12	874
1618	733	716	1118	856	12	866
1619	1225	543	1650	801	12	866
1620	887	682	1348	904	12	856
1621	568	654	985	907	12	847
1622	848	701	1119	852	12	847
1623	754	704	1129	862	12	838
1624	404	373	736	751	12	838
1625	740	710	1116	854	12	828
1626	635	56	954	419	12	828
1627	744	701	1129	846	12	819
1628	1125	182	1568	410	12	819
1629	907	146	1354	397	12	823
1630	746	697	1121	852	12	823
1631	1251	263	1690	509	12	814
1632	750	692	1130	854	12	814
1633	1249	536	1659	798	12	804
1634	750	708	1124	853	12	804
1635	920	672	1366	904	12	795
1636	756	703	960	851	12	795
1637	599	624	1019	891	12	786
1638	869	708	1124	856	12	786
1639	496	350	813	717	12	777
1640	751	708	1124	864	12	777
1641	754	700	1130	872	12	767
1642	716	86	1039	452	12	767
1643	1038	238	1456	476	12	758
1644	750	699	1134	873	12	758
1645	1279	463	1698	723	12	748
1646	758	717	1130	873	12	748
1647	1145	610	1588	873	12	739
1648	762	717	1133	868	12	739
1649	762	691	1203	912	12	730
1650	481	511	841	841	12	720
1651	763	699	1129	869	12	720
1652	759	699	1137	871	12	712
1653	610	157	896	545	12	712
1654	755	703	1131	868	12	702
1655	894	173	1314	461	12	702
1656	1128	374	1555	617	12	693
1657	766	721	1134	876	12	693
1658	1143	598	1560	835	12	683
1659	761	723	1136	872	12	683
1660	875	676	1315	902	12	675
1661	470	515	838	840	12	665
1662	775	723	1134	865	12	665
1663	762	700	1125	874	12	656
1664	578	142	836	540	12	656
1665	760	702	1132	864	12	646
1666	834	165	1225	480	12	646
1667	1177	389	1593	611	12	637
1668	769	718	1137	861	12	637
1669	1223	574	1643	826	12	628
1670	755	700	1139	868	12	628
1672	927	686	1358	912	12	618
1673	645	648	1065	892	12	611
1674	760	716	1137	874	12	601
1675	570	323	881	692	12	601
1676	718	81	1045	426	12	592
1677	762	709	1127	866	12	592
1678	1085	250	1516	485	12	582
1679	762	713	1130	860	12	582
1680	756	718	1127	859	12	575
1681	1255	390	1691	649	12	575
1682	1020	650	1448	896	12	565
1683	755	725	1039	864	12	565
1684	623	619	1034	892	12	556
1685	896	709	1132	852	12	556
1686	768	711	1120	859	12	546
1687	564	197	828	592	12	546
1688	760	716	1125	855	12	539
1689	685	124	1002	488	12	539
1690	763	698	1137	868	12	529
1691	1222	252	1660	469	12	529
1692	1317	450	1756	704	12	520
1693	763	722	1127	859	12	520
1694	1040	650	1475	864	12	510
1695	754	724	1054	859	12	510
1696	753	660	1186	890	12	503
1697	569	331	881	695	12	493
1698	748	711	1124	862	12	493
1699	755	709	1128	864	12	486
1700	657	93	948	469	12	486
1701	1022	226	1442	469	12	476
1702	746	700	1127	855	12	476
1703	1178	407	1611	624	12	469
1704	751	702	1120	861	12	469
1705	1144	597	1573	839	12	459
1706	757	702	1115	855	12	459
1707	739	663	1176	891	12	452
1708	753	723	1110	856	12	442
1709	509	456	835	788	12	442
1710	604	145	844	535	12	435
1711	754	683	1114	858	12	435
1712	749	701	1113	861	12	425
1713	822	216	1240	520	12	425
1714	1084	347	1504	576	12	418
1715	740	704	1111	854	12	418
1716	1205	555	1613	805	12	408
1717	741	716	1116	857	12	408
1718	1065	664	1493	879	12	401
1719	743	714	1084	859	12	401
1720	597	610	1003	874	12	391
1721	749	698	1131	858	12	384
1722	508	257	801	649	12	384
1723	752	699	1119	850	12	374
1724	833	141	1264	448	12	374
1725	1172	281	1599	510	12	367
1726	750	719	1124	849	12	367
1727	1184	554	1601	798	12	357
1728	745	703	1124	846	12	357
1729	1012	644	1435	873	12	350
1730	746	705	1035	842	12	350
1731	756	656	1175	876	12	340
1732	489	386	831	744	12	332
1733	744	677	1104	842	12	332
1734	703	62	1052	419	12	322
1735	742	676	1109	841	12	322
1736	999	165	1413	419	12	315
1737	746	694	1122	840	12	315
1738	1277	399	1701	643	12	305
1739	742	687	1111	834	12	305
1740	1125	599	1555	835	12	295
1741	748	691	1108	832	12	295
1742	1038	645	1471	854	12	293
1743	740	710	1060	829	12	293
1744	633	630	1052	872	12	283
1745	744	685	1105	836	12	275
1746	425	407	743	746	12	275
1747	741	676	1111	835	12	265
1748	644	34	960	411	12	265
1749	743	687	1107	826	12	256
1750	999	188	1413	423	12	256
1751	747	687	1116	837	12	246
1752	1218	495	1627	730	12	246
1753	1006	630	1422	852	12	238
1754	743	686	1016	831	12	238
1755	614	633	1027	868	12	228
1756	749	680	1108	827	12	219
1757	390	509	740	817	12	219
1758	743	685	1106	835	12	210
1759	499	107	760	514	12	210
1760	745	681	1114	826	12	202
1761	951	197	1354	433	12	202
1762	746	680	1113	828	12	193
1763	1137	328	1564	550	12	193
1764	1089	596	1499	831	12	183
1765	749	680	1103	822	12	183
1766	748	626	1175	848	12	173
1767	490	313	812	669	12	163
1768	745	679	1111	833	12	163
1769	747	655	1120	827	12	153
1770	775	69	1163	390	12	153
1771	752	685	1123	832	12	137
1772	1196	527	1608	759	12	137
1773	759	632	1180	860	12	127
1774	553	564	933	834	12	117
1775	815	676	1124	818	12	117
1776	759	684	1139	832	12	102
1777	744	51	1108	405	12	102
1778	762	689	1134	826	12	92
1779	1102	327	1532	559	12	92
1780	770	690	1213	920	12	853
1781	457	585	865	881	12	843
1782	774	709	1133	855	12	843
1783	756	718	1130	868	12	834
1784	458	201	731	601	12	834
1785	756	707	1117	852	12	824
1786	839	125	1283	398	12	824
1787	1267	278	1683	506	12	815
1788	764	713	1119	859	12	815
1789	1270	514	1700	777	12	805
1790	745	711	1129	862	12	805
1791	960	671	1396	900	12	796
1792	742	717	1003	861	12	796
1793	635	648	1050	888	12	787
1794	765	732	1130	879	12	778
1795	486	410	831	744	12	778
1796	755	704	1124	867	12	768
1797	677	89	992	450	12	768
1798	758	706	1128	872	12	759
1799	1032	225	1458	470	12	759
1800	1273	434	1694	694	12	749
1801	756	725	1124	873	12	749
1802	1187	601	1610	863	12	740
1803	756	716	1144	870	12	740
1804	803	691	1258	917	12	731
1805	479	531	867	866	12	721
1806	778	710	1139	869	12	721
1807	767	722	1135	872	12	713
1808	587	218	867	597	12	713
1809	767	717	1141	875	12	703
1810	853	151	1256	444	12	703
1811	763	731	1138	874	12	694
1812	1126	364	1536	585	12	694
1813	774	727	1140	877	12	684
1814	1154	580	1580	817	12	684
1815	930	678	1367	908	12	676
1816	781	720	1144	865	12	666
1817	499	554	864	863	12	666
1818	565	193	825	577	12	657
1819	764	696	1136	865	12	657
1820	766	719	1130	869	12	647
1821	782	143	1170	464	12	647
1822	1143	361	1575	590	12	638
1823	764	704	1131	869	12	638
1824	1237	562	1662	820	12	629
1825	759	715	1135	864	12	629
1826	973	681	1402	915	12	619
1827	687	662	1100	904	12	612
1828	546	358	887	724	12	602
1829	766	729	1133	875	12	602
1830	754	704	1136	872	12	593
1831	711	68	1047	422	12	593
1832	752	717	1130	867	12	583
1833	1029	227	1475	479	12	583
1834	1231	371	1669	632	12	576
1835	745	694	1130	861	12	576
1836	1058	637	1496	882	12	566
1837	762	709	1098	858	12	566
1838	691	655	1115	900	12	557
1839	762	723	1142	873	12	547
1840	536	293	834	664	12	547
1841	760	713	1125	868	12	540
1842	584	79	849	475	12	540
1843	1170	210	1614	445	12	530
1844	747	696	1137	862	12	530
1845	1339	448	1762	685	12	521
1846	751	715	1133	860	12	521
1847	1058	619	1501	850	12	511
1848	733	727	1104	864	12	511
1849	839	654	1276	895	12	504
1850	561	414	899	754	12	494
1851	750	695	1115	861	12	487
1852	640	105	922	500	12	487
1853	746	706	1129	864	12	477
1854	992	227	1402	460	12	477
1855	1170	366	1596	601	12	470
1856	754	701	1117	864	12	470
1857	750	703	1117	858	12	460
1858	1123	610	1546	845	12	460
1859	850	659	1279	891	12	453
1860	506	494	865	819	12	443
1861	749	699	1120	864	12	443
1862	578	202	846	587	12	436
1863	747	683	1131	863	12	436
1864	742	698	1124	865	12	426
1865	810	200	1233	516	12	426
1866	737	686	1115	862	12	419
1867	1051	328	1480	580	12	419
1868	1205	555	1614	790	12	409
1869	736	700	1123	857	12	409
1870	1095	639	1527	878	12	402
1871	747	703	1112	851	12	402
1872	642	632	1061	885	12	392
1873	751	704	1127	863	12	385
1874	503	319	806	686	12	385
1875	748	708	1124	851	12	375
1876	769	101	1176	448	12	375
1877	1129	253	1571	492	12	368
1878	744	694	1124	851	12	368
1879	1212	538	1644	788	12	358
1880	744	692	1129	849	12	358
1881	1039	632	1457	862	12	351
1882	738	694	1064	847	12	351
1883	786	644	1226	892	12	341
1884	486	315	802	685	12	333
1885	730	680	1111	852	12	333
1886	737	683	1117	849	12	323
1887	667	56	999	431	12	323
1888	946	151	1375	408	12	316
1889	735	682	1121	842	12	316
1890	1268	368	1692	621	12	306
1891	740	666	1123	838	12	306
1892	1159	578	1599	823	12	296
1893	732	688	1117	838	12	296
1894	670	629	1099	873	12	285
1895	740	680	1126	844	12	274
1896	401	472	769	812	12	274
1897	721	638	1117	835	12	264
1898	660	18	1004	390	12	264
1899	1188	355	1625	603	12	248
1900	734	657	1118	849	12	248
1901	945	622	1407	865	12	237
1902	721	669	980	838	12	237
1903	738	667	1123	833	12	221
1904	399	555	783	854	12	221
1905	430	218	719	622	12	212
1906	736	656	1111	845	12	212
1907	733	661	1124	845	12	201
1908	774	101	1219	427	12	201
1909	1196	389	1633	623	12	191
1910	731	667	1128	831	12	191
1911	1110	576	1541	822	12	182
1912	744	672	1110	832	12	182
1913	687	610	1140	853	12	172
1914	535	178	833	574	12	162
1915	748	645	1117	839	12	162
1916	808	82	1244	403	12	152
1917	738	661	1132	837	12	152
1918	1202	411	1628	685	12	136
1919	755	662	1127	835	12	136
1920	888	626	1330	854	12	126
1921	512	508	912	826	12	116
1922	749	664	1141	832	12	116
1923	750	64	1152	423	12	101
1924	753	671	1143	834	12	101
1925	1092	319	1525	568	12	91
1926	758	657	1140	833	12	91
1927	681	72	1039	432	12	1008
1928	738	703	1117	865	12	1008
1929	1096	266	1551	509	12	996
1930	724	709	1128	873	12	996
1931	988	638	1417	864	12	979
1932	736	714	1017	858	12	979
1933	695	684	1137	932	12	968
1934	736	722	1129	865	12	951
1935	562	134	876	561	12	951
1936	1047	158	1516	396	12	941
1937	743	694	1130	870	12	941
1938	1254	462	1692	712	12	930
1939	743	723	1125	868	12	930
1940	820	657	1289	877	12	917
1941	513	662	929	916	12	906
1942	751	692	1121	860	12	906
1943	450	370	782	738	12	896
1944	740	696	1120	873	12	896
1945	919	151	1341	424	12	883
1946	739	698	1118	872	12	883
1947	1237	474	1666	740	12	869
1948	744	691	1128	859	12	869
1949	1034	649	1472	895	12	859
1950	731	705	1061	868	12	859
1951	528	648	946	902	12	846
1952	773	696	1126	853	12	846
1953	738	685	1124	867	12	832
1954	508	120	762	522	12	832
1955	747	678	1128	863	12	818
1956	1169	202	1610	428	12	818
1957	750	694	1137	871	12	808
1958	1321	435	1757	693	12	808
1959	886	677	1307	907	12	794
1960	506	510	876	826	12	781
1961	762	704	1140	870	12	781
1962	758	687	1135	873	12	771
1963	598	125	880	524	12	771
1964	756	689	1130	875	12	757
1965	1078	263	1490	498	12	757
1966	1248	552	1673	811	12	743
1967	750	688	1134	865	12	743
1968	729	684	1149	930	12	729
1969	478	473	817	808	12	719
1970	765	697	1133	874	12	719
1971	757	665	1137	868	12	706
1972	767	103	1169	442	12	706
1973	762	683	1149	880	12	692
1974	1146	394	1580	625	12	692
1975	1116	605	1549	854	12	682
1976	765	691	1137	869	12	682
1977	603	636	1007	899	12	669
1978	815	697	1159	873	12	669
1979	763	691	1145	875	12	655
1980	593	110	865	499	12	655
1981	760	687	1140	868	12	641
1982	1065	324	1498	543	12	641
1983	1192	591	1622	850	12	627
1984	752	686	1143	873	12	627
1985	750	684	1185	917	12	614
1986	756	707	1131	881	12	604
1987	526	432	886	768	12	604
1988	762	690	1131	876	12	591
1989	738	69	1126	434	12	591
1990	752	685	1130	862	12	578
1991	1206	322	1649	582	12	578
1992	1114	608	1547	862	12	568
1993	752	686	1119	861	12	568
1994	574	595	996	882	12	555
1995	740	685	1124	857	12	542
1996	613	78	901	473	12	542
1997	1020	212	1452	450	12	532
1998	745	661	1138	881	12	532
1999	1288	482	1732	739	12	519
2000	756	677	1136	860	12	519
2001	913	656	1361	880	12	506
2002	755	698	1140	870	12	496
2003	571	450	922	782	12	496
2006	751	700	1141	865	12	471
2007	1139	332	1572	569	12	471
2013	749	676	1120	869	12	427
2014	739	158	1193	518	12	427
2004	756	705	1125	861	12	483
2005	743	118	1098	470	12	483
2008	1147	572	1588	841	12	461
2009	759	681	1126	857	12	461
2011	738	677	1123	873	12	437
2012	565	255	859	653	12	437
2019	683	653	1107	901	12	393
2024	1240	506	1676	771	12	359
2025	743	665	1127	849	12	359
2030	725	654	1126	842	12	325
2031	588	79	908	466	12	325
2034	1264	496	1706	741	12	301
2035	733	657	1115	852	12	301
2039	738	657	1116	845	12	272
2040	461	324	776	703	12	272
2050	733	658	1111	827	12	216
2051	394	377	705	747	12	216
2010	631	623	1079	896	12	449
2015	1152	450	1594	686	12	415
2016	745	694	1123	865	12	415
2017	1130	617	1549	864	12	403
2018	731	683	1115	864	12	403
2020	747	679	1135	875	12	381
2021	567	114	848	516	12	381
2022	737	664	1134	873	12	369
2023	1097	241	1517	470	12	369
2026	955	644	1378	890	12	347
2027	749	686	986	846	12	347
2028	531	521	909	817	12	335
2029	753	689	1119	843	12	335
2032	726	657	1122	848	12	312
2033	1096	214	1535	478	12	312
2036	870	638	1324	865	12	290
2037	736	657	1120	845	12	280
2038	425	521	828	864	12	280
2041	736	650	1127	837	12	262
2042	689	9	1041	391	12	262
2043	741	654	1123	832	12	253
2044	1167	300	1580	541	12	253
2045	736	656	1122	843	12	244
2046	1156	549	1585	793	12	244
2047	802	648	1241	881	12	234
2048	504	609	918	882	12	226
2049	755	656	1118	827	12	226
2052	740	650	1119	841	12	208
2053	585	45	883	419	12	208
2054	736	644	1129	832	12	198
2055	1098	292	1528	530	12	198
2056	1191	528	1611	772	12	188
2057	749	647	1115	826	12	188
2058	946	637	1380	871	12	179
2059	751	667	1122	826	12	169
2060	566	532	972	820	12	169
2061	743	663	1131	845	12	161
2062	489	262	816	635	12	161
2063	748	654	1126	836	12	151
2064	864	115	1295	422	12	151
2065	1139	332	1576	581	12	143
2066	751	629	1125	840	12	143
2067	1133	553	1558	795	12	133
2068	747	654	1120	822	12	133
2069	557	586	964	854	12	118
2070	759	645	1134	827	12	108
2071	551	56	828	473	12	108
2072	763	649	1135	830	12	100
2073	794	91	1211	410	12	100
2074	1129	356	1563	580	12	90
2075	754	638	1146	830	12	90
2076	540	671	957	916	12	907
2077	734	678	1122	851	12	907
2078	760	673	1121	870	12	897
2079	435	417	775	771	12	897
2080	710	72	1083	403	12	887
2081	738	677	1126	858	12	887
2082	742	676	1124	863	12	877
2083	1113	293	1541	527	12	877
2084	1197	571	1617	836	12	864
2085	743	682	1124	858	12	864
2086	662	672	1085	920	12	850
2087	753	660	1119	862	12	841
2088	415	519	780	854	12	841
2089	739	664	1117	861	12	831
2090	504	77	807	485	12	831
2091	750	673	1124	869	12	822
2092	993	155	1439	401	12	822
2093	1302	323	1746	581	12	812
2094	754	680	1130	861	12	812
2095	1220	553	1657	820	12	803
2096	738	675	1131	868	12	803
2097	830	673	1283	908	12	793
2098	481	478	858	815	12	780
2099	753	685	1124	869	12	780
2100	745	689	1124	877	12	770
2101	614	105	902	471	12	770
2102	750	681	1139	870	12	761
2103	953	190	1392	466	12	761
2104	1248	386	1676	651	12	751
2105	749	677	1145	881	12	751
2106	1228	555	1659	831	12	742
2107	748	682	1137	878	12	742
2108	891	675	1347	920	12	733
2109	510	592	921	892	12	723
2110	789	688	1157	871	12	723
2111	767	698	1137	880	12	715
2112	524	294	821	675	12	715
2113	752	663	1135	875	12	705
2114	794	103	1202	446	12	705
2115	1093	307	1516	547	12	696
2116	754	676	1135	900	12	696
2117	1163	535	1601	784	12	686
2118	740	677	1141	885	12	686
2119	1000	641	1460	908	12	678
2120	755	709	1030	878	12	678
2121	526	574	960	901	12	668
2122	758	688	1136	872	12	659
2123	511	272	784	662	12	659
2124	746	677	1134	884	12	649
2125	741	111	1117	457	12	649
2126	751	694	1141	882	12	640
2127	1084	333	1525	566	12	640
2128	887	711	1135	867	12	668
2129	763	722	946	865	12	733
\.


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.labels (id, name, color, groupid) FROM stdin;
12	Shoe	rgba(235, 20, 76, 1)	12
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, email) FROM stdin;
1	admin	$2a$06$gyL3y8TyVmdkXmUqk4XyzO.N5.EOy7QvS9YHtOrrojFwWONMJGzfC	flhansen.93@gmail.com
2	mifrank	$2a$06$QX1z.hCLZyKpKP2mAzED6.n.2UIDR8Dq1yoorovfjzag0UMckUfKm	michael.frank@stud.hs-flensburg.de
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_id_seq', 1, true);


--
-- Name: image_groups_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.image_groups_categoryid_seq', 1, false);


--
-- Name: image_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.image_groups_id_seq', 13, true);


--
-- Name: image_groups_userid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.image_groups_userid_seq', 1, false);


--
-- Name: images_groupid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_groupid_seq', 1, false);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 1128, true);


--
-- Name: labelings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.labelings_id_seq', 2130, true);


--
-- Name: labelings_imageid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.labelings_imageid_seq', 1, false);


--
-- Name: labelings_labelid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.labelings_labelid_seq', 1, false);


--
-- Name: labels_groupid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.labels_groupid_seq', 1, false);


--
-- Name: labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.labels_id_seq', 12, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: image_groups image_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups
    ADD CONSTRAINT image_groups_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: labelings labelings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings
    ADD CONSTRAINT labelings_pkey PRIMARY KEY (id);


--
-- Name: labels labels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: image_groups image_groups_categoryid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups
    ADD CONSTRAINT image_groups_categoryid_fkey FOREIGN KEY (categoryid) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: image_groups image_groups_userid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.image_groups
    ADD CONSTRAINT image_groups_userid_fkey FOREIGN KEY (userid) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: images images_groupid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_groupid_fkey FOREIGN KEY (groupid) REFERENCES public.image_groups(id) ON DELETE CASCADE;


--
-- Name: labelings labelings_imageid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings
    ADD CONSTRAINT labelings_imageid_fkey FOREIGN KEY (imageid) REFERENCES public.images(id) ON DELETE CASCADE;


--
-- Name: labelings labelings_labelid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labelings
    ADD CONSTRAINT labelings_labelid_fkey FOREIGN KEY (labelid) REFERENCES public.labels(id) ON DELETE CASCADE;


--
-- Name: labels labels_groupid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.labels
    ADD CONSTRAINT labels_groupid_fkey FOREIGN KEY (groupid) REFERENCES public.image_groups(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

